VSL AUTO EDITOR — MÓDULO 05 (protótipo local)

1. Instale FFmpeg/ffprobe e deixe-os no PATH.
2. Execute INICIAR.bat no Windows.
3. Leia a pasta da biblioteca contendo base 1.mp4, base 2.mp4 etc e B-rolls.
4. Clique Organizar bases numericamente.
5. Use Reproduzir montagem para conferir base + inserções (som da base; B-roll sem áudio).
6. Opcional: carregue SRT com timestamps e clique Sugerir B-rolls pelo texto.
7. Salve o plano e exporte somente para projeto CapCut duplicado e fechado.

LIMITES: prévia sincronizada no navegador é aproximada, não render final; SRT deve ser fornecido (sem transcrição automática); matching é por palavras no nome/categoria, não análise visual ou LLM. Exportador CapCut continua baseado no M04: injeta B-rolls no projeto existente, não substitui bases nem gera transições nativas. Faça backup e teste antes de produção.
