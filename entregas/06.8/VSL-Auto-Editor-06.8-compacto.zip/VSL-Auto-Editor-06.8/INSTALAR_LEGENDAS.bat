@echo off
cd /d "%~dp0"
echo Instalando transcricao local. Requer internet para pacotes e primeiro modelo.
python -m venv .venv
if errorlevel 1 goto erro
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements-legendas.txt
if errorlevel 1 goto erro
echo Pronto. Reinicie pelo INICIAR.bat.
pause
exit /b 0
:erro
echo Falha na instalacao. Use Python 3.11 ou 3.12 e confira a mensagem acima.
pause
exit /b 1
