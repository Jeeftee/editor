"""One visual model for preview, masks and transparent export assets.

Coordinates are canvas fractions; mask coordinates are panel fractions.
Custom visuals are baked as transparent ProRes 4444, never invented native masks.
"""
import math, subprocess, uuid
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageChops

DEFAULT = {'x':0.,'y':0.,'scale':1.,'rotation':0.,'opacity':1.,'brightness':1.,'contrast':1.,'saturation':1.,'grayscale':0.,'sepia':0.}
MASK = {'type':'none','x':.5,'y':.5,'width':1.,'height':1.,'feather':0.,'roundness':0.,'invert':False}

def number(value, low, high, field):
    try: value=float(value)
    except (TypeError, ValueError): raise ValueError('Ajuste visual inválido: '+field)
    if not math.isfinite(value) or not low<=value<=high: raise ValueError('Ajuste visual fora do limite: '+field)
    return value

def normalized(entry):
    raw=entry.get('visual') or {}
    if not isinstance(raw,dict): raise ValueError('Ajustes visuais inválidos.')
    v=dict(DEFAULT)
    for key,(low,high) in {'x':(-2,2),'y':(-2,2),'scale':(.1,4),'rotation':(-180,180),'opacity':(0,1),'brightness':(.2,2),'contrast':(.2,2),'saturation':(0,2),'grayscale':(0,1),'sepia':(0,1)}.items():
        v[key]=number(raw.get(key,v[key]),low,high,key)
    m=raw.get('mask') or {}
    if not isinstance(m,dict): raise ValueError('Máscara inválida.')
    mask=dict(MASK);mask.update(m)
    if mask['type'] not in ('none','rectangle','circle','split'): raise ValueError('Tipo de máscara inválido.')
    for key,(low,high) in {'x':(0,1),'y':(0,1),'width':(.05,2),'height':(.05,2),'feather':(0,1),'roundness':(0,1)}.items():
        mask[key]=number(mask[key],low,high,'mask.'+key)
    if not isinstance(mask['invert'],bool): raise ValueError('Inversão de máscara inválida.')
    v['mask']=mask
    layer=number(entry.get('layer',0),0,3,'camada')
    if layer!=int(layer): raise ValueError('Camada deve ser inteira.')
    return v

def changed(entry):
    v=normalized(entry)
    return any(v[k]!=value for k,value in DEFAULT.items()) or v['mask']['type']!='none'

def geometry(info, entry, panel='full', size=(1080,1920)):
    cw,ch=size;ph=ch*(.7 if panel=='expert' else .3 if panel=='broll' else 1)
    pw=cw;py=ch*.7 if panel=='broll' else 0
    w,h=info['width'],info['height'];crop=entry.get('crop') or {}
    top=crop.get('top',0) if panel=='broll' else 0;bottom=crop.get('bottom',1) if panel=='broll' else 1
    if not 0<=top<bottom<=1: raise ValueError('Recorte inválido.')
    if panel=='full':
        rect=(0,0,w,h);ratio=min(pw/w,ph/h);dw=w*ratio;dh=h*ratio
    else:
        wanted=pw/ph;content_h=h*(bottom-top)
        sw=min(w,content_h*wanted);sh=min(content_h,w/wanted)
        center_y=.36*h if panel=='expert' else (top+bottom)*h/2
        center_y=max(top*h+sh/2,min(bottom*h-sh/2,center_y))
        rect=((w-sw)/2,center_y-sh/2,sw,sh);dw=pw;dh=ph
    return {'panel':(round(pw),round(ph),round(py)), 'source':rect, 'draw':((pw-dw)/2,(ph-dh)/2,dw,dh)}

def mask_image(v, panel_size, content_rect=None):
    w,h=panel_size;m=v['mask'];img=Image.new('L',(w,h),255 if m['type']=='none' else 0)
    if m['type']!='none':
        draw=ImageDraw.Draw(img);mw=m['width']*w;mh=m['height']*h;cx=m['x']*w;cy=m['y']*h
        box=(cx-mw/2,cy-mh/2,cx+mw/2,cy+mh/2)
        if m['type']=='circle': draw.ellipse(box,fill=255)
        elif m['type']=='split': draw.rectangle((0,cy,w,h),fill=255)
        else: draw.rounded_rectangle(box,radius=min(mw,mh)*m['roundness']/2,fill=255)
        if m['invert']: img=ImageChops.invert(img)
        if m['feather']: img=img.filter(ImageFilter.GaussianBlur(min(w,h)*.08*m['feather']))
    if content_rect:
        x,y,dw,dh=content_rect;bounds=Image.new('L',(w,h));ImageDraw.Draw(bounds).rectangle((x,y,x+dw-1,y+dh-1),fill=255);img=ImageChops.multiply(img,bounds)
    return img

def bake(entry, info, folder, panel='full', fade_in=0, fade_out=0, size=(1080,1920)):
    """Bake only an edited segment; source remains untouched. Audio is preserved."""
    v=normalized(entry);g=geometry(info,entry,panel,size);pw,ph,py=g['panel'];cw,ch=size
    name=uuid.uuid4().hex;dest=Path(folder)/(name+'.mov');mask=Path(folder)/(name+'_mask.png')
    mask_image(v,(pw,ph),g['draw']).save(mask)
    sx,sy,sw,sh=g['source'];dx,dy,dw,dh=g['draw']
    # Round dimensions once; preview mirrors the same integer fit at export size.
    dw,dh=max(1,round(dw)),max(1,round(dh));dx,dy=round(dx),round(dy)
    fit=[f'crop={max(1,round(sw))}:{max(1,round(sh))}:{round(sx)}:{round(sy)}',f'scale={dw}:{dh}:flags=lanczos','format=rgba',f'pad={pw}:{ph}:{dx}:{dy}:color=black@0']
    filters=[]
    if v['brightness']!=1 or v['contrast']!=1 or v['saturation']!=1:
        # colorchannelmixer implements CSS brightness (multiplicative), not eq offset.
        filters += [f'colorchannelmixer=rr={v["brightness"]}:gg={v["brightness"]}:bb={v["brightness"]}',f'eq=contrast={v["contrast"]}:saturation={v["saturation"]}']
    if v['grayscale']: filters += ['hue=s=0']
    if v['sepia']: filters += ['colorchannelmixer=rr=.393:rg=.769:rb=.189:gr=.349:gg=.686:gb=.168:br=.272:bg=.534:bb=.131']
    filters += ['format=rgba']
    chain='[0:v]'+','.join(fit)+'[fitted];[fitted]split=2[color][original];[original]alphaextract[originalalpha];[originalalpha][1:v]blend=all_mode=multiply[combinedalpha];[color]'+','.join(filters)+'[picture];[picture][combinedalpha]alphamerge[masked];'
    transform=[f'colorchannelmixer=aa={v["opacity"]}']
    if fade_in: transform += [f'fade=t=in:st=0:d={fade_in}:alpha=1']
    if fade_out: transform += [f'fade=t=out:st={max(0,entry["duration"]-fade_out)}:d={fade_out}:alpha=1']
    scaledw=max(2,round(pw*v['scale']/2)*2);scaledh=max(2,round(ph*v['scale']/2)*2)
    transform += [f'scale={scaledw}:{scaledh}:flags=lanczos']
    angle=v['rotation']*math.pi/180
    if angle: transform += [f'rotate={angle}:ow=rotw({angle}):oh=roth({angle}):c=black@0']
    chain+='[masked]'+','.join(transform)+'[moved];'
    x=cw/2+v['x']*cw;y=py+ph/2+v['y']*ch
    length=entry['duration']
    chain+=f'color=c=black@0:s={cw}x{ch}:r=30:d={length},format=rgba[bg];[bg][moved]overlay=x={x}-overlay_w/2:y={y}-overlay_h/2:format=auto:shortest=1,format=yuva444p10le[out]'
    cmd=['ffmpeg','-v','error','-y','-filter_complex_threads','1']
    image=Path(entry['path']).suffix.lower() in ('.png','.jpg','.jpeg','.webp','.bmp')
    if image: cmd += ['-loop','1','-framerate','30']
    else: cmd += ['-ss',str(entry.get('source_start',0))]
    cmd += ['-i',str(entry['path']),'-loop','1','-i',str(mask),'-filter_complex',chain,'-map','[out]','-map','0:a?','-t',str(length),'-c:v','prores_ks','-profile:v','4','-pix_fmt','yuva444p10le','-c:a','pcm_s16le',str(dest)]
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=max(180,length*40))
        if r.returncode: raise ValueError('Falha ao preparar máscara/efeito: '+r.stderr[-1000:])
    finally:
        mask.unlink(missing_ok=True)
    return dest
