"""Bounded graphical overlays, optional AI description interpreter; never execute generated code."""
import json, math, os, re, subprocess, uuid
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
from captions063 import font_path

def normalize(e):
    s={'id':str(e.get('id') or uuid.uuid4().hex),'kind':e.get('kind','arrow'),'start':e.get('start',0),'duration':e.get('duration',3),'x':e.get('x',.5),'y':e.get('y',.5),'size':e.get('size',.22),'rotation':e.get('rotation',0),'color':e.get('color','#ffd84a'),'text':str(e.get('text',''))[:120],'animation':e.get('animation','pulse'),'motion_offset':e.get('motion_offset',0),'motion_duration':e.get('motion_duration',e.get('duration',3)),'value':e.get('value',100)}
    for k,lo,hi in [('start',0,100000),('duration',.1,60),('x',0,1),('y',0,1),('size',.03,1),('rotation',-180,180),('motion_offset',0,100000),('motion_duration',.1,100000),('value',0,1000000)]:
        try:s[k]=float(s[k])
        except (TypeError,ValueError):raise ValueError('Parâmetro de efeito inválido: '+k)
        if not math.isfinite(s[k]) or not lo<=s[k]<=hi:raise ValueError('Parâmetro de efeito fora do limite: '+k)
    from studio068 import KINDS,MOTIONS
    if s['kind'] not in KINDS:raise ValueError('Efeito disponível: seta, círculo, caixa ou texto.')
    if s['animation'] not in MOTIONS:raise ValueError('Animação de efeito inválida.')
    if not isinstance(s['color'],str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',s['color']):raise ValueError('Cor de efeito inválida.')
    return s

def validate_effects(effects,duration):
    if not isinstance(effects,list) or len(effects)>100:raise ValueError('Limite de 100 efeitos gráficos.')
    for e in effects:
        s=normalize(e)
        if s['start']+s['duration']>duration+.002:raise ValueError('Efeito fora da narração.')

def generate(payload):
    prompt=str(payload.get('prompt','')).strip()
    if not prompt or len(prompt)>2000:raise ValueError('Descreva o efeito em até 2000 caracteres.')
    mode=payload.get('mode','local')
    if mode=='local':
        t=prompt.lower();kind='arrow' if 'seta' in t else 'ring' if any(w in t for w in ('círculo','circulo','anel')) else 'box' if any(w in t for w in ('caixa','retângulo','retangulo')) else 'text' if 'texto' in t else None
        if kind is None:raise ValueError('Modo local: descreva seta, círculo, caixa ou texto. Para interpretar livremente use a conexão de IA.')
        result={'kind':kind,'animation':'slide' if 'desliz' in t else 'pop' if 'pop' in t else 'none' if 'sem anima' in t else 'pulse','color':'#ff4444' if 'vermelh' in t else '#ffffff' if 'branc' in t else '#ffd84a','text':payload.get('text','')}
        method='Preset local por palavras; não usa IA.'
    elif mode=='openai':
        key=str(payload.get('apiKey') or os.environ.get('VSL_AI_KEY') or '').strip();model=str(payload.get('model','')).strip()
        if not key:raise ValueError('Informe sua chave de API ou configure VSL_AI_KEY. A chave não é salva no plano.')
        if not re.fullmatch(r'[a-zA-Z0-9._:-]{1,100}',model):raise ValueError('Informe um modelo da sua conta que aceite saída estruturada.')
        properties={'kind':{'type':'string','enum':['arrow','ring','box','text']},'animation':{'type':'string','enum':['none','pulse','pop','slide']},'color':{'type':'string'},'text':{'type':'string'},'rotation':{'type':'number'},'size':{'type':'number'}}
        schema={'type':'object','properties':properties,'required':list(properties),'additionalProperties':False}
        data={'model':model,'store':False,'input':[{'role':'system','content':'Converta a descrição em um efeito gráfico sobreposto. Retorne somente os parâmetros. Não invente suporte a efeitos fora do catálogo. Tamanho entre .03 e 1; rotação entre -180 e 180; cor hexadecimal #RRGGBB. A posição será ajustada pelo usuário.'},{'role':'user','content':prompt}], 'text':{'format':{'type':'json_schema','name':'overlay','strict':True,'schema':schema}}}
        request=Request('https://api.openai.com/v1/responses',data=json.dumps(data).encode(),headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
        try:
            with urlopen(request,timeout=90) as r:response=json.load(r)
        except HTTPError as ex:raise ValueError('A conexão de IA retornou erro HTTP '+str(ex.code)+'. Confira chave, modelo e saldo da API.') from None
        except (URLError,TimeoutError):raise ValueError('Não foi possível conectar à IA. Confira a internet e tente novamente.') from None
        raw=''.join(c.get('text','') for item in response.get('output',[]) for c in item.get('content',[]) if c.get('type')=='output_text')
        try:result=json.loads(raw)
        except ValueError:raise ValueError('A IA não retornou um efeito utilizável.') from None
        method='Descrição interpretada pela IA; gráfico do catálogo local.'
    else:raise ValueError('Modo de geração inválido.')
    e=normalize({**result,'start':payload.get('start',0),'duration':payload.get('duration',3),'x':payload.get('x',.5),'y':payload.get('y',.5)})
    return {'effect':e,'method':method,'scope':'Sobreposição gráfica: seta, círculo, caixa ou texto. Não gera movimento dentro da imagem; não envia arquivos de mídia à IA.'}

def frame(e,t,size=(540,960)):
    from studio068 import motion_values
    e=normalize(e);w,h=size;elapsed=t-e['start'];motion=motion_values({**e,'motion':e['animation']},elapsed);scale=motion['scale'];offset=motion['x']*w
    a=e['size']*w*scale;layer=Image.new('RGBA',(w,h));d=ImageDraw.Draw(layer);cx=w/2;cy=h/2;c=e['color'];line=max(2,round(a*.06))
    if e['kind']=='arrow':d.polygon([(cx-a/2,cy-a*.08),(cx+a*.12,cy-a*.08),(cx+a*.12,cy-a*.25),(cx+a/2,cy),(cx+a*.12,cy+a*.25),(cx+a*.12,cy+a*.08),(cx-a/2,cy+a*.08)],fill=c)
    elif e['kind']=='ring':d.ellipse((cx-a/2,cy-a/2,cx+a/2,cy+a/2),outline=c,width=line)
    elif e['kind']=='box':d.rounded_rectangle((cx-a/2,cy-a*.3,cx+a/2,cy+a*.3),radius=a*.08,outline=c,width=line)
    elif e['kind']=='particles':
        for i in range(12):
            angle=i*math.pi/6+(elapsed+e['motion_offset'])*1.3;radius=a*(.25+.15*math.sin((elapsed+e['motion_offset'])*2+i))
            px=cx+math.cos(angle)*radius;py=cy+math.sin(angle)*radius
            d.ellipse((px-line,py-line,px+line,py+line),fill=c)
    elif e['kind']=='progress':
        d.rounded_rectangle((cx-a/2,cy-a*.06,cx+a/2,cy+a*.06),radius=line,outline=c,width=line)
        progress=min(1,max(0,(elapsed+e['motion_offset'])/e['motion_duration']))
        if progress:d.rectangle((cx-a/2,cy-a*.06,cx-a/2+a*progress,cy+a*.06),fill=c)
    else:
        if e['kind']=='lowerthird':d.rounded_rectangle((cx-a/2,cy-a*.19,cx+a/2,cy+a*.19),radius=line,fill=c)
        if e['kind']=='badge':d.ellipse((cx-a/2,cy-a/2,cx+a/2,cy+a/2),fill=c)
        path=font_path('arial');font=ImageFont.truetype(str(path),max(12,round(a*.2))) if path else ImageFont.load_default();text=str(round(e['value']*min(1,max(0,(elapsed+e['motion_offset'])/e['motion_duration'])))) if e['kind']=='counter' else e['text'] or 'Destaque';d.text((cx,cy),text,font=font,fill='#ffffff' if e['kind'] in ('lowerthird','badge') else c,stroke_width=2,stroke_fill='black',anchor='mm')
    layer=layer.rotate(-(e['rotation']+motion['rotation']),resample=Image.Resampling.BICUBIC);out=Image.new('RGBA',(w,h));out.alpha_composite(layer,(round((e['x']-.5)*w+offset),round((e['y']-.5+motion['y'])*h)));out.putalpha(out.getchannel('A').point(lambda v:round(v*motion['opacity'])));return out

def bake_effect(e,folder):
    e=normalize(e);dest=Path(folder)/(uuid.uuid4().hex+'_effect.mov');fps=30
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s','540x960','-r',str(fps),'-i','pipe:0','-vf','scale=1080:1920','-c:v','prores_ks','-profile:v','4','-pix_fmt','yuva444p10le','-threads','2',str(dest)]
    # File-backed stderr prevents a blocked pipe on failure.
    err=Path(folder)/(dest.stem+'.log')
    try:
        with err.open('wb') as log:
            process=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=log)
            try:
                for i in range(math.ceil(e['duration']*fps)):process.stdin.write(frame(e,e['start']+i/fps).tobytes())
                process.stdin.close();code=process.wait(timeout=180)
            except Exception:
                process.kill();process.wait();raise
        if code:raise ValueError('Não foi possível renderizar o efeito gráfico.')
    finally:err.unlink(missing_ok=True)
    return dest
