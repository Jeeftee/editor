"""Clear only app-owned reproducible data, preserving media and edit history."""
from pathlib import Path
import shutil
from editor06 import ROOT, JOBS

TEMPORARIES=('transcript_cache','thumbnails','integrations','hf_frames')

def targets(models=False):
    data=ROOT/'data'
    result=[data/name for name in TEMPORARIES]+[data/'media_probe_cache.json']
    if models:result.append(ROOT/'models')
    for path in result:
        if path.is_symlink() or getattr(path,'is_junction',lambda:False)() or not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError('Diretório de cache redirecionado; limpeza recusada.')
    return result

def size(path):
    if not path.exists():return 0
    if path.is_file():return path.stat().st_size
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(path.resolve()))

def summary():
    return {'temporary_bytes':sum(size(p) for p in targets()),'models_bytes':size(ROOT/'models'),'preserved':['Vídeos e imagens originais','Plano salvo e catálogo','Histórico de seleção aleatória','Inserções geradas e projetos exportados']}

def clear(models=False):
    if any(j.get('status')=='running' for j in JOBS.values()):
        raise ValueError('Aguarde a análise ou transcrição terminar antes de limpar o cache.')
    before=summary();errors=[]
    for path in targets(models):
        try:
            if path.is_dir():shutil.rmtree(path)
            elif path.is_file():path.unlink()
        except OSError:errors.append(path.name+': arquivo em uso; tente após reiniciar o editor.')
    after=summary()
    freed=before['temporary_bytes']-after['temporary_bytes']
    if models:freed+=before['models_bytes']-after['models_bytes']
    return {**after,'freed_bytes':max(0,freed),'errors':errors}
