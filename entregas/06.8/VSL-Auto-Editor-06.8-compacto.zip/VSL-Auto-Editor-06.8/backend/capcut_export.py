import copy, json, os, shutil, tempfile, uuid
from datetime import datetime
from pathlib import Path
from catalog import probe

def uid(): return str(uuid.uuid4()).upper()
def export(project_dir, clips, audio_levels, confirmation):
    if confirmation != 'EXPORTAR': raise ValueError('Confirme com EXPORTAR.')
    folder=Path(project_dir).expanduser().resolve()
    draft=folder/'draft_content.json'
    if not draft.is_file(): raise ValueError('Nao encontrei draft_content.json nessa pasta.')
    if len(clips)>300: raise ValueError('Limite de 300 insercoes por teste.')
    data=json.loads(draft.read_text(encoding='utf-8'))
    tracks=[t for t in data['tracks'] if t.get('type')=='video' and t.get('segments')]
    if not tracks: raise ValueError('Projeto precisa ter pelo menos uma faixa de video.')
    target=tracks[-1]
    segment_template=target['segments'][0]
    material_template=next((m for m in data['materials']['videos'] if m['id']==segment_template['material_id']),None)
    if material_template is None: raise ValueError('Material modelo nao encontrado.')
    new_tracks=[]
    ordered=sorted(clips,key=lambda x:float(x['start']))
    for left,right in zip(ordered,ordered[1:]):
        if float(left['start'])+float(left['duration'])>float(right['start'])+0.001:
            raise ValueError('B-rolls sobrepostos. Ative o ima e ajuste a timeline antes de exportar.')
    all_segments=[]
    for index,item in enumerate(clips):
        p=Path(item['path']).resolve()
        if not p.is_file() or p.suffix.lower()!='.mp4': raise ValueError('MP4 inexistente: '+str(p))
        meta=probe(p)
        if meta['error'] or not meta['duration']: raise ValueError('MP4 invalido: '+str(p))
        start=float(item['start']); duration=float(item['duration']); source=float(item.get('source_start',0))
        if start<0 or duration<=0 or source<0 or source+duration>meta['duration']+.05: raise ValueError('Tempo invalido: '+p.name)
        mat=copy.deepcopy(material_template)
        mat.update({'id':uid(),'unique_id':uuid.uuid4().hex,'path':p.as_posix(),'media_path':'','material_name':p.name,'duration':round(meta['duration']*1e6),'width':meta['width'],'height':meta['height'],'has_audio':bool(meta.get('has_audio',True)),'has_sound_separated':False,'source':0,'source_platform':0,'category_id':'','category_name':'','material_id':'','material_url':'','request_id':'','is_copyright':False})
        data['materials']['videos'].append(mat)
        seg=copy.deepcopy(segment_template)
        seg.update({'id':uid(),'material_id':mat['id'],'volume':float(audio_levels.get('insertVolume',.3)),'last_nonzero_volume':float(audio_levels.get('insertVolume',.3)),'source_timerange':{'start':round(source*1e6),'duration':round(duration*1e6)},'target_timerange':{'start':round(start*1e6),'duration':round(duration*1e6)},'render_timerange':{'start':0,'duration':0},'keyframe_refs':[],'common_keyframes':[],'group_id':'','desc':'VSL AUTO M03'})
        refs=[]
        for old_id in seg.get('extra_material_refs',[]):
            found=False
            for collection in data['materials'].values():
                if not isinstance(collection,list):continue
                for entry in list(collection):
                    if isinstance(entry,dict) and entry.get('id')==old_id:
                        clone=copy.deepcopy(entry);clone['id']=uid();collection.append(clone);refs.append(clone['id']);found=True;break
                if found:break
            if not found: raise ValueError('Referencia auxiliar nao encontrada: '+old_id)
        seg['extra_material_refs']=refs
        if isinstance(seg.get('clip'),dict):
            seg['clip']['scale']={'x':1.0,'y':1.0}
            seg['clip']['transform']={'x':0.0,'y':0.0}
        seg['render_index']=len(tracks)
        seg['track_render_index']=len(tracks)
        all_segments.append(seg)
        data['duration']=max(data.get('duration',0),round((start+duration)*1e6))
    track=copy.deepcopy(target)
    track.update({'id':uid(),'segments':all_segments,'name':'VSL AUTO B-ROLLS','is_default_name':False,'flag':0,'attribute':0})
    new_tracks.append(track)
    last=max(i for i,t in enumerate(data['tracks']) if t.get('type')=='video')
    data['tracks'][last+1:last+1]=new_tracks
    # Preserve all original audio tracks and their volumes.
    backup=folder/('draft_content.backup_m03_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.json')
    shutil.copy2(draft,backup)
    fd,temp=tempfile.mkstemp(prefix='vsl_m03_',suffix='.json',dir=folder)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,separators=(',',':'))
        os.replace(temp,draft)
    finally:
        if os.path.exists(temp):os.unlink(temp)
    return {'inserted':len(new_tracks),'backup':str(backup),'project':str(folder)}
