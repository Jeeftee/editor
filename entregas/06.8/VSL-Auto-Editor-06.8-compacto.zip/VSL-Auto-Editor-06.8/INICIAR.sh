#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
command -v ffmpeg >/dev/null || { echo 'Instale FFmpeg no seu sistema.'; exit 1; }
command -v ffprobe >/dev/null || { echo 'Instale FFprobe no seu sistema.'; exit 1; }
if [ -x .venv/bin/python ]; then vsl_python=.venv/bin/python; else vsl_python=python3; fi
"$vsl_python" -c 'import PIL, numpy' || { echo 'Instale os requisitos: python3 -m venv .venv && .venv/bin/python -m pip install -r requirements.txt'; exit 1; }
exec "$vsl_python" backend/main.py "$@"
