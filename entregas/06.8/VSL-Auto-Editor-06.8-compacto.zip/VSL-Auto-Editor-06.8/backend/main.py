import json, mimetypes, subprocess, random, array, math, sys, threading, webbrowser
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from catalog import scan
from database import load,save
from capcut_export import export
from style_engine import read_profile, suggest
from transition_style import analyze, audit_native
from rhythm_style import analyze_rhythm
from editor06 import library, audio_analysis, split_detection, transcribe_job, JOBS, preliminary_faces, caption_groups, validate
from export06 import export_plan
from register_capcut import register
from integrations import imported_transcript, suggest_by_transcript, review, run_job, render_graphic, asset_path
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'frontend'/'index.html').read_bytes()
PLAN=ROOT/'data'/'timeline_plan.json'
MUSIC=ROOT/'data'/'music_catalog.json'
SFX=ROOT/'data'/'sfx_catalog.json'
def music_items():
 return json.loads(MUSIC.read_text(encoding='utf-8')) if MUSIC.exists() else []
def scan_music(folder):
 root=Path(folder).expanduser().resolve()
 if not root.is_dir():raise ValueError('Pasta de musicas nao encontrada.')
 out=[]
 for f in sorted(root.rglob('*')):
  if not f.is_file() or f.suffix.lower() not in {'.mp3','.m4a','.wav','.ogg','.aac','.mp4','.flac','.mov','.mkv','.webm'}:continue
  try:
   r=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(f)],capture_output=True,text=True,timeout=15,check=True)
   duration=float(json.loads(r.stdout)['format']['duration'])
   streams=subprocess.run(['ffprobe','-v','error','-select_streams','a','-show_entries','stream=codec_type','-of','json',str(f)],capture_output=True,text=True,timeout=15,check=True)
   if duration>.1 and json.loads(streams.stdout).get('streams'):
    item={'path':str(f),'name':f.name,'duration':round(duration,3)}
    try:
     item.update(audio_analysis(f,split=True))
    except Exception:pass
    out.append(item)
  except Exception:pass
 return out

class Handler(BaseHTTPRequestHandler):
 def send_data(self,obj,status=200,ctype='application/json; charset=utf-8'):
  b=obj if isinstance(obj,bytes) else json.dumps(obj,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
 def do_GET(self):
  p=urlparse(self.path)
  if p.path=='/':return self.send_data(HTML,ctype='text/html; charset=utf-8')
  if p.path=='/studio068.js':return self.send_data((ROOT/'frontend/studio068.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/api/coverage':return self.send_error(405)
  if p.path=='/studio064.js':return self.send_data((ROOT/'frontend/studio064.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/studio062.js':return self.send_data((ROOT/'frontend/studio062.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/visual063.js':return self.send_data((ROOT/'frontend/visual063.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/captions063.js':return self.send_data((ROOT/'frontend/captions063.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/api/captions/styles':
   from captions063 import catalog
   return self.send_data(catalog())
  if p.path=='/api/captions/font':
   from captions063 import font_path
   try:
    font=font_path(parse_qs(p.query).get('id',[''])[0])
    if not font:return self.send_error(404)
    return self.send_data(font.read_bytes(),ctype='font/ttf')
   except (ValueError,OSError):return self.send_error(404)
  if p.path=='/editor06.js':return self.send_data((ROOT/'frontend/editor06.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/integrations.js':return self.send_data((ROOT/'frontend/integrations.js').read_bytes(),ctype='text/javascript; charset=utf-8')
  if p.path=='/api/integrations/asset':
   try:
    f=asset_path(parse_qs(p.query).get('file',[''])[0]);return self.send_data(f.read_bytes(),ctype=mimetypes.guess_type(f.name)[0] or 'text/plain; charset=utf-8')
   except ValueError:return self.send_error(404)
  if p.path=='/api/capcut/index':
   import os
   root=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData/Local')))/'CapCut/User Data/Projects'
   found=None
   for candidate in [root/'com.lveditor.draft/root_meta_info.json',root/'root_meta_info.json']:
    try:
     if candidate.is_file():found=str(candidate);break
    except OSError:pass
   return self.send_data({'path':found})
  if p.path=='/api/transitions/library':return self.send_data(library())
  if p.path=='/api/jobs':return self.send_data(JOBS.get(parse_qs(p.query).get('id',[''])[0],{'status':'error','error':'Tarefa desconhecida.'}))
  if p.path=='/api/thumbnail':
   try:
    from thumbnails062 import thumbnail
    return self.send_data(thumbnail(parse_qs(p.query).get('path',[''])[0],load()),ctype='image/jpeg')
   except Exception:return self.send_error(404)
  if p.path=='/api/videos':return self.send_data(load())
  if p.path=='/api/music':return self.send_data(music_items())
  if p.path=='/api/sfx':return self.send_data(json.loads(SFX.read_text(encoding='utf-8')) if SFX.exists() else [])
  if p.path=='/api/cache':
   from cache062 import summary
   return self.send_data(summary())
  if p.path=='/api/plan':return self.send_data(json.loads(PLAN.read_text(encoding='utf-8')) if PLAN.exists() else {'clips':[],'voice':1,'music':.3})
  if p.path=='/api/preview':
   requested=parse_qs(p.query).get('path',[''])[0]
   # Only allow already catalogued paths.
   if requested not in {v['path'] for v in load()}|{v['path'] for v in music_items()}|{v['path'] for v in (json.loads(SFX.read_text(encoding='utf-8')) if SFX.exists() else [])}:return self.send_error(404)
   f=Path(requested)
   if not f.is_file() or f.suffix.lower() not in {'.mp4','.mp3','.m4a','.wav','.ogg','.aac','.flac','.mov','.mkv','.webm','.png','.jpg','.jpeg','.webp','.bmp'}:return self.send_error(404)
   size=f.stat().st_size;start=0;end=size-1;rh=self.headers.get('Range','')
   if rh.startswith('bytes='):
    try:
     bounds=rh[6:].split('-',1);start=int(bounds[0]) if bounds[0] else 0;end=min(int(bounds[1]),size-1) if bounds[1] else end
     if start>=size or end<start:raise ValueError()
    except ValueError:return self.send_error(416)
   self.send_response(206 if rh else 200);self.send_header('Content-Type',mimetypes.guess_type(str(f))[0] or 'application/octet-stream');self.send_header('Accept-Ranges','bytes');self.send_header('Content-Length',str(end-start+1))
   if rh:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
   self.end_headers()
   try:
    with f.open('rb') as stream:
     stream.seek(start);left=end-start+1
     while left:
      block=stream.read(min(65536,left))
      if not block:break
      self.wfile.write(block);left-=len(block)
   except (BrokenPipeError,ConnectionResetError):pass
   return
  self.send_error(404)
 def do_POST(self):
  try:
   n=int(self.headers.get('Content-Length','0'))
   if n>(16000000 if self.path=='/api/render/frame' else 10000000):return self.send_error(413)
   payload=json.loads(self.rfile.read(n))
   if self.headers.get('Origin') and self.headers['Origin'] not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):return self.send_data({'error':'Origem inválida.'},403)
   if self.path=='/api/sfx/synthesize':
    from studio068 import synthesize
    item=synthesize(payload);items=json.loads(SFX.read_text(encoding='utf8')) if SFX.exists() else [];items=[x for x in items if x['path']!=item['path']]+[item];SFX.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf8');return self.send_data(item)
   if self.path=='/api/images/import':
    from studio068 import import_image
    return self.send_data(import_image(payload))
   if self.path=='/api/coverage':
    from studio068 import coverage
    return self.send_data(coverage(payload,load()))
   if self.path=='/api/render/start':
    from render064 import start
    return self.send_data(start(payload,load(),music_items(),json.loads(SFX.read_text(encoding='utf-8')) if SFX.exists() else []))
   if self.path=='/api/render/frame':
    from render064 import append
    return self.send_data(append(payload))
   if self.path=='/api/render/cancel':
    from render064 import cancel
    return self.send_data(cancel(payload.get('session')))
   if self.path=='/api/render/finish':
    from render064 import finish
    token=payload.get('session')
    return self.send_data(run_job(lambda progress:finish(token,progress)))
   if self.path=='/api/effects/generate':
    from effects064 import generate
    return self.send_data(generate(payload))
   if self.path=='/api/integrations/import':return self.send_data(imported_transcript(payload,load()))
   if self.path=='/api/integrations/suggest':return self.send_data(suggest_by_transcript(payload,load()))
   if self.path=='/api/integrations/review':
    catalog=load();validate(payload,catalog);return self.send_data(run_job(lambda progress:review(payload,catalog,progress)))
   if self.path=='/api/integrations/hyperframes':
    def generate(progress):
     result=render_graphic(payload,progress);items=scan(str(Path(result['path']).parent),'insercoes');save(items,merge=True)
     return result
    return self.send_data(run_job(generate))
   if self.path=='/api/captions/import':return self.send_data({'captions':caption_groups(payload.get('segments',[]))})
   if self.path=='/api/captions/styles/import':
    from captions063 import reference_styles
    return self.send_data(reference_styles(payload.get('folder','')))
   if self.path=='/api/capcut/register':return self.send_data(register(payload.get('project',''),payload.get('index','')))
   if self.path=='/api/captions/transcribe':return self.send_data(transcribe_job(payload,load()))
   if self.path=='/api/split/detect':
    if not any(v['path']==payload.get('path') and v['category']=='insercoes' for v in load()):raise ValueError('Selecione uma inserção catalogada.')
    return self.send_data(split_detection(payload['path']))
   if self.path=='/api/faces/preliminary':
    if not any(v['path']==payload.get('base',{}).get('path') and v['category']=='especialista' for v in load()):raise ValueError('Selecione uma base catalogada.')
    return self.send_data(preliminary_faces(payload['base']))
   if self.path=='/api/sfx/scan':
    items=scan_music(payload.get('folder',''));SFX.parent.mkdir(parents=True,exist_ok=True);SFX.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8');return self.send_data({'count':len(items),'items':items})
   if self.path=='/api/rhythm/analyze':
    return self.send_data(analyze_rhythm(payload.get('folder','')))
   if self.path=='/api/music/scan':
    items=scan_music(payload.get('folder',''));MUSIC.parent.mkdir(parents=True,exist_ok=True);MUSIC.write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8');return self.send_data({'count':len(items),'items':items})
   if self.path=='/api/transitions/native-audit':
    return self.send_data(audit_native(payload.get('folder','')))
   if self.path=='/api/transitions/analyze':
    return self.send_data(analyze(payload.get('folder','')))
   if self.path=='/api/style':
    return self.send_data(read_profile(payload.get('path','')))
   if self.path=='/api/suggest':
    return self.send_data(suggest(payload,load()))
   if self.path=='/api/project/load':
    from project062 import load_project
    return self.send_data(load_project(payload.get('folder',''),scan_music,MUSIC,SFX))
   if self.path=='/api/scan':
    items=scan(payload.get('folder',''),payload.get('category'));save(items,merge=bool(payload.get('category')))
    return self.send_data({'count':len(items),'categories':dict(Counter(x['category'] for x in items)),'errors':sum(bool(x['error']) for x in items)})
   if self.path=='/api/cache/clear':
    from cache062 import clear
    return self.send_data(clear(bool(payload.get('models'))))
   if self.path=='/api/plan':
    clips=payload.get('clips',[])
    allowed={v['path'] for v in load()}
    if len(clips)>3000 or len(payload.get('bases',[]))>100 or any(c.get('path') not in allowed for c in clips+payload.get('bases',[])):raise ValueError('Clipes invalidos ou fora do catalogo.')
    if payload.get('bases'):validate(payload,load())
    from studio068 import validate_music,validate_sounds
    duration=max([b['start']+b['duration'] for b in payload.get('bases',[])]+[1])
    validate_music(payload,music_items(),duration)
    validate_sounds(payload,json.loads(SFX.read_text(encoding='utf8')) if SFX.exists() else [],duration)
    encoded=json.dumps(payload,ensure_ascii=False,indent=2)
    if payload.get('projectFolder'):
     folder=Path(payload['projectFolder']).expanduser().resolve()
     if not folder.is_dir():raise ValueError('Pasta do projeto não encontrada.')
     destination=folder/'vsl-plan-06.8.json';temporary=destination.with_suffix('.tmp');temporary.write_text(encoded,encoding='utf8');temporary.replace(destination)
    PLAN.parent.mkdir(parents=True,exist_ok=True);temporary=PLAN.with_suffix('.tmp');temporary.write_text(encoded,encoding='utf8');temporary.replace(PLAN)
    return self.send_data({'saved':True})
   if self.path=='/api/export':
    return self.send_data(export_plan(payload,load(),music_items(),json.loads(SFX.read_text(encoding='utf-8')) if SFX.exists() else []))
   self.send_error(404)
  except Exception as e:self.send_data({'error':str(e)},400)
if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=None);parser.add_argument('--no-browser',action='store_true');args=parser.parse_args()
 if args.port is not None and not 1024<=args.port<=65535:parser.error('Porta inválida.')
 ports=[args.port] if args.port is not None else range(8765,8781)
 for port in ports:
  try:
   server=ThreadingHTTPServer(('127.0.0.1',port),Handler);break
  except OSError as exc:
   if exc.errno not in (98,48,10048) or args.port is not None:raise
 else:raise RuntimeError('Nenhuma porta local disponível; encerre um editor antigo e tente novamente.')
 args.port=server.server_port
 print(f'VSL Auto Editor 06.8: http://127.0.0.1:{args.port}');print('Ctrl+C para parar.')
 if not args.no_browser:threading.Timer(.5,lambda:webbrowser.open(f'http://127.0.0.1:{args.port}')).start()
 server.serve_forever()
