from reference062 import draft_files
"""Extract contiguous overlay runs from CapCut projects, without treating music as B-roll."""
import json, statistics
from pathlib import Path

def analyze_rhythm(folder):
 root=Path(folder).expanduser().resolve()
 if not root.is_dir():raise ValueError('Pasta de exemplos nao encontrada.')
 runs=[]; gaps=[]; shots=[]; examined=0; project_summaries=[]
 for p in list(draft_files(root))[:200]:
  if 'subdraft' in str(p.relative_to(root)).lower():continue
  try:d=json.loads(p.read_text(encoding='utf-8-sig'))
  except (ValueError,OSError):continue
  examined+=1
  tracks=[t for t in d.get('tracks',[]) if t.get('type')=='video']
  intervals=[]
  for track in tracks:
   for seg in track.get('segments',[]):
    r=seg.get('target_timerange') or {};start=float(r.get('start',0))/1e6;end=start+float(r.get('duration',0))/1e6
    if end>start:intervals.append((start,end,seg.get('material_id')))
  if not intervals:continue
  # A longest video segment beginning at zero is a likely base, but not proof.
  base=max(intervals,key=lambda x:x[1]-x[0]); overlays=sorted((a,b) for a,b,m in intervals if (a,b,m)!=base and b-a>=.2)
  if not overlays:continue
  grouped=[]
  for a,b in overlays:
   shots.append(b-a)
   if grouped and a<=grouped[-1][1]+.25:grouped[-1]=(grouped[-1][0],max(b,grouped[-1][1]))
   else:grouped.append((a,b))
  runs.extend(b-a for a,b in grouped)
  gaps.extend(max(0,grouped[i+1][0]-grouped[i][1]) for i in range(len(grouped)-1))
  project_summaries.append({'project':p.parent.name,'blocks':len(grouped),'overlay_s':round(sum(b-a for a,b in grouped),2)})
 def stats(a):return {'median':round(statistics.median(a),2),'p25':round(sorted(a)[int((len(a)-1)*.25)],2),'p75':round(sorted(a)[int((len(a)-1)*.75)],2),'samples':len(a)} if a else None
 return {'projects_scanned':examined,'projects_with_overlays':len(project_summaries),'broll_blocks':stats(runs),'expert_gaps':stats(gaps),'individual_inserts':stats(shots),'projects':project_summaries[:30],'warning':'Heurística: a maior faixa de vídeo iniciada em zero é considerada base. Confira os números; projetos com múltiplas câmeras podem exigir revisão.'}
