"""Encode the same preview canvas into MP4; mix audio locally without loading the whole film into RAM."""
import base64, io, json, math, shutil, subprocess, threading, uuid, time
from pathlib import Path
import numpy as np
from PIL import Image
from editor06 import ROOT,validate,sfx_events
from catalog import probe,IMAGES
SESSIONS={};FPS=30;RATE=48000

def start(plan,catalog,music,sfx):
    if len(SESSIONS)>=2:raise ValueError('Há exportações em andamento; finalize ou cancele antes de iniciar outra.')
    duration=validate(plan,catalog)
    if plan.get('musicPath') and not any(x['path']==plan['musicPath'] for x in music):raise ValueError('Música fora da biblioteca.')
    from studio068 import validate_music,validate_sounds
    validate_music(plan,music,duration)
    validate_sounds(plan,sfx,duration)
    width,height=(720,1280) if plan.get('resolution')=='hd' else (1080,1920)
    events=sfx_events(plan,sfx)
    for e in events:
        item=next((x for x in sfx if x['path']==e.get('path')),None)
        if not item or not 0<=float(e.get('gain',.3))<=2 or e['start']<0 or e['duration']<=0 or e['start']+e['duration']>duration+.002 or e.get('source_start',0)<0 or e.get('source_start',0)+e['duration']>item['duration']+.002:raise ValueError('Efeito sonoro inválido.')
    parent=Path(plan.get('mp4Folder') or ROOT/'exports').expanduser().resolve();parent.mkdir(parents=True,exist_ok=True)
    token=uuid.uuid4().hex;temp=parent/('.vsl_render_'+token);temp.mkdir();dest=parent/('VSL06_8_'+token[:10]+'.mp4')
    log=(temp/'encoder.log').open('wb');silent=temp/'picture.mp4'
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s',f'{width}x{height}','-r',str(FPS),'-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-threads','2',str(silent)]
    try:p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=log)
    except Exception:log.close();shutil.rmtree(temp);raise
    SESSIONS[token]={'width':width,'height':height,'plan':plan,'catalog':catalog,'music':music,'sfx':sfx,'duration':duration,'count':0,'frames':math.ceil(duration*FPS),'process':p,'temp':temp,'dest':dest,'log':log,'lock':threading.Lock(),'updated':time.monotonic(),'finishing':False}
    return {'session':token,'frames':math.ceil(duration*FPS),'fps':FPS,'width':width,'height':height}

def session(token):
    s=SESSIONS.get(token)
    if not s:raise ValueError('Exportação inexistente ou já encerrada.')
    return s

def append(payload):
    s=session(payload.get('session'));index=payload.get('index')
    with s['lock']:
        if index!=s['count'] or s['count']>=s['frames']:raise ValueError('Quadro fora de ordem.')
        try:
            raw=base64.b64decode(str(payload.get('image','')),validate=True)
            with Image.open(io.BytesIO(raw)) as image:
                if image.size!=(s['width'],s['height']):raise ValueError('Quadro com tamanho inválido.')
                s['process'].stdin.write(image.convert('RGBA').tobytes())
        except BrokenPipeError:raise ValueError('O renderizador interrompeu a exportação.') from None
        s['count']+=1;s['updated']=time.monotonic()
    return {'received':s['count']}

def cancel(token,force=False):
    existing=SESSIONS.get(token)
    if existing and existing['finishing'] and not force:return {'cancelled':False,'finishing':True}
    s=SESSIONS.pop(token,None)
    if not s:return {'cancelled':True}
    with s['lock']:
        if s['process'].poll() is None:s['process'].kill();s['process'].wait()
        s['process'].stdin.close();s['log'].close();shutil.rmtree(s['temp'])
    return {'cancelled':True}

def mix_audio(s,progress):
    plan=s['plan'];duration=s['duration'];samples=math.ceil(duration*RATE);temp=s['temp'];raw=temp/'mix.f32'
    mix=np.memmap(raw,dtype='float32',mode='w+',shape=(samples,2));mix[:]=0
    try:
        def add(path,start,length,source,gain,fade_in=0,fade_out=0):
            offset=round(start*RATE);length=min(length,duration-start)
            if length<1/RATE or gain==0:return
            logpath=temp/'audio.log'
            with logpath.open('wb') as log:
                p=subprocess.Popen(['ffmpeg','-v','error','-ss',str(source),'-i',str(path),'-t',f'{length:.9f}','-vn','-ac','2','-ar',str(RATE),'-f','f32le','pipe:1'],stdout=subprocess.PIPE,stderr=log)
                cursor=0;carry=b''
                try:
                    while True:
                        block=p.stdout.read(65536)
                        if not block:break
                        block=carry+block;usable=len(block)//8*8;carry=block[usable:];a=np.frombuffer(block[:usable],dtype='float32').reshape(-1,2)
                        count=min(len(a),samples-offset-cursor)
                        if count<=0:continue
                        local=(cursor+np.arange(count))/RATE;envelope=np.ones(count)
                        if fade_in:envelope=np.minimum(envelope,local/fade_in)
                        if fade_out:envelope=np.minimum(envelope,(length-local)/fade_out)
                        mix[offset+cursor:offset+cursor+count]+=a[:count]*(np.clip(envelope,0,1)*gain)[:,None];cursor+=count
                    if p.wait(timeout=30):raise ValueError('Não foi possível decodificar um áudio da montagem.')
                except Exception:
                    p.kill();p.wait();raise
                finally:p.stdout.close()
        progress('Misturando voz, música e efeitos sonoros...')
        for b in plan['bases']:add(b['path'],b['start'],b['duration'],b.get('source_start',0),plan.get('voice',1))
        for c in plan.get('clips',[]):
            if Path(c['path']).suffix.lower() not in IMAGES and probe(c['path']).get('has_audio'):add(c['path'],c['start'],c['duration'],c.get('source_start',0),plan.get('insertVolume',.3))
        music=next((x for x in s['music'] if x['path']==plan.get('musicPath')),None)
        if plan.get('musicManual'):
            for c in plan.get('musicClips',[]):add(c['path'],c['start'],c['duration'],c.get('source_start',0),c.get('gain',plan.get('music',.3)),c.get('fade_in',0),c.get('fade_out',0))
        elif music:
            trim=min(music.get('audible_start_s',0),max(0,music['duration']-.5));usable=music['duration']-trim;overlap=min(float(plan.get('musicCrossfade',2.5)),usable*.4);cycle=usable-overlap
            if cycle<=.1:raise ValueError('Música curta demais.')
            t=0;i=0
            while t<duration-.00001:
                length=min(usable,duration-t);add(music['path'],t,length,trim,plan.get('music',.3),overlap if i else 0,overlap if t+usable<duration else 0);t+=cycle;i+=1
        for e in sfx_events(plan,s['sfx']):add(e['path'],e['start'],e['duration'],e.get('source_start',0),e.get('gain',plan.get('sfxVolume',.3)),min(.12,e['duration']/2),min(.3,e['duration']/2))
        peak=0
        for i in range(0,samples,RATE*10):peak=max(peak,float(np.max(np.abs(mix[i:i+RATE*10]))))
        if peak>.99:
            for i in range(0,samples,RATE*10):mix[i:i+RATE*10]*=.99/peak
        mix.flush()
        return raw,peak
    finally:
        mix.flush();mix._mmap.close()


def finish(token,progress=lambda _:None):
    s=session(token)
    try:
        s['finishing']=True
        with s['lock']:
            if s['count']!=s['frames']:raise ValueError('Exportação incompleta: faltam quadros.')
            s['process'].stdin.close()
            if s['process'].wait(timeout=180):raise ValueError('Não foi possível finalizar o vídeo.')
            s['log'].close()
        raw,peak=mix_audio(s,progress);partial=s['temp']/'final.mp4';progress('Finalizando MP4 e verificando o arquivo...')
        r=subprocess.run(['ffmpeg','-v','error','-y','-i',str(s['temp']/'picture.mp4'),'-f','f32le','-ar',str(RATE),'-ac','2','-i',str(raw),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t',str(s['duration']),'-movflags','+faststart',str(partial)],capture_output=True,timeout=max(180,s['duration']*2))
        if r.returncode:raise ValueError('Não foi possível finalizar o áudio do MP4.')
        metadata=probe(partial)
        if metadata.get('error') or not metadata.get('has_audio') or abs(metadata['duration']-s['duration'])>.1:raise ValueError('O MP4 não passou na verificação de duração e áudio.')
        partial.replace(s['dest']);report={'version':'06.8','resolution':[s['width'],s['height']],'fps':30,'duration':metadata['duration'],'has_audio':True,'preview_canvas':True,'audio_peak_before_normalization':peak,'native_transitions':'Aparência aproximada da prévia, não o motor nativo do CapCut.'}
        s['dest'].with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        return {'path':str(s['dest']),'validation':report}
    finally:cancel(token,force=True)


def expire_abandoned():
    while True:
        time.sleep(30)
        for token,s in list(SESSIONS.items()):
            if not s['finishing'] and time.monotonic()-s['updated']>300:
                try:cancel(token)
                except OSError:pass
threading.Thread(target=expire_abandoned,daemon=True).start()
