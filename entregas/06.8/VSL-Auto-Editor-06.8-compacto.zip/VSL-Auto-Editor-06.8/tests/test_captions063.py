import sys, unittest, tempfile, json, shutil, uuid
from pathlib import Path
APP=Path(__file__).resolve().parents[1];sys.path.insert(0,str(APP/'backend'))
from captions063 import normalized, states, content, word_timings, reference_styles
from export06 import Draft

class Captions(unittest.TestCase):
    def test_word_highlight_respects_pauses(self):
        c={'start':1.,'end':2.5,'text':'Fala bem clara','timing':'word','words':[{'word':'Fala','start':1,'end':1.2},{'word':'bem','start':1.5,'end':1.7},{'word':'clara','start':2,'end':2.5}]}
        segments=states(c,normalized({'captionStyle':{'karaoke':True,'animation':'none'}}))
        gap=next(s for s in segments if s['start']==1.2);self.assertEqual(gap['active_word'],-1)
        active=next(s for s in segments if s['start']==1.5);self.assertEqual(active['active_word'],1);self.assertFalse(active['estimated'])
        rich=content(active,normalized({'captionStyle':{'karaoke':True}}));self.assertNotEqual(rich['styles'][0]['fill'],rich['styles'][1]['fill'])
    def test_typewriter_and_estimated_timing(self):
        c={'start':0,'end':3,'text':'um dois três'};s=states(c,normalized({'captionStyle':{'animation':'typewriter'}}))
        self.assertEqual([v['text'] for v in s],['um','um dois','um dois três']);self.assertTrue(all(v['estimated'] for v in s))
    def test_caption_controls_are_validated(self):
        for bad in [{'size':float('nan')},{'font':'arbitrary_path'},{'color':'javascript:foo'},{'animation':'arbitrary_effect'},{'y':2}]:
            with self.assertRaises(ValueError):normalized({'captionStyle':bad})
    def test_native_editable_text_font_and_animation(self):
        root=APP/'tests'/('caption063_'+uuid.uuid4().hex);root.mkdir()
        try:
            d=Draft(root,'Legenda');d.captions([{'start':0,'end':1,'text':'fala clara'}],{'font':'impact','uppercase':True,'color':'#ffd84a','animation':'pop'})
            m=d.data['materials']['texts'][0];s=d.data['tracks'][0]['segments'][0]
            self.assertEqual(m['font_name'],'Impact');self.assertEqual(json.loads(m['content'])['text'],'FALA CLARA');self.assertEqual(len(s['common_keyframes']),2)
            none=Draft(root/'plain','Sem animação') if False else None
            d.captions([{'start':1,'end':2,'text':'sem animação'}],{'animation':'none'})
            self.assertEqual(d.data['tracks'][-1]['segments'][0]['common_keyframes'],[])
        finally:shutil.rmtree(root)
    def test_reference_import_maps_unavailable_font(self):
        root=APP/'tests'/('refs063_'+uuid.uuid4().hex);root.mkdir()
        try:
            (root/'draft_content.json.bak').write_text(json.dumps({'materials':{'texts':[{'font_name':'ZY Starry','font_size':10,'text_color':'#ffffff','border_width':.08}]}}),encoding='utf8')
            r=reference_styles(root);self.assertEqual(len(r['presets']),1);self.assertTrue(r['presets'][0]['font_substituted']);self.assertEqual(r['presets'][0]['style']['font'],'arial')
        finally:shutil.rmtree(root)
if __name__=='__main__':unittest.main(verbosity=2)
