VSL Auto Editor 06.8 — baseado na 06.4-estudio.
Instalação e recursos: LEIA-ME-06.8.txt.
Windows: CONFIGURAR.bat e INICIAR.bat.
Linux/macOS com Python + FFmpeg: INICIAR.sh.
Testes e limitações: VALIDACAO-06.8.json.
