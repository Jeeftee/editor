import json, random, statistics
from pathlib import Path

def read_profile(path):
    p=Path(path).expanduser()
    if not p.is_absolute():p=Path(__file__).resolve().parents[1]/p
    if not p.is_file() or p.suffix.lower()!='.json': raise ValueError('Selecione um perfil JSON existente.')
    data=json.loads(p.read_text(encoding='utf-8-sig'))
    records=data.get('projects_detail',data.get('projects',[]))
    if not isinstance(records,list): raise ValueError('Perfil sem lista de projetos.')
    records=[r for r in records if isinstance(r,dict) and 'subdraft' not in str(r.get('source','')).lower()]
    lengths=[float(x) for r in records for x in r.get('video_clip_durations_s',[]) if .25<=float(x)<=12]
    if not lengths: raise ValueError('Perfil sem durações válidas de clipes.')
    median=round(statistics.median(lengths),2)
    return {'projects':len(records),'clip_samples':len(lengths),'median_short_clip_s':median,'cadence_s':max(1,min(8,median)), 'note':'Duração estrutural estimada; não classifica semântica nem identifica expert.'}

def suggest(payload, catalog):
    style=read_profile(payload.get('profile',''))
    length=float(payload.get('length',90))
    if not .5<=length<=86400:raise ValueError('Duração deve ficar entre 0,5 segundos e 24 horas.')
    pool=[v for v in catalog if not v.get('error') and (v.get('duration') or 0)>.4 and v.get('category')=='insercoes']
    if not pool:raise ValueError('Nenhum B-roll válido no catálogo. Importe a biblioteca primeiro.')
    pool.sort(key=lambda v:(str(v.get('category','')),str(v.get('name',''))))
    from selection062 import choose_opening
    opening,selection=choose_opening(pool)
    rng=random.SystemRandom()
    rng.shuffle(pool)
    pool.remove(opening);pool.insert(0,opening)
    rhythm=payload.get('rhythmStats') or {}
    cadence=float((rhythm.get('individual_inserts') or {}).get('median') or style['cadence_s'])
    cadence=max(.5,min(12,cadence))
    block=float((rhythm.get('broll_blocks') or {}).get('median') or 13.5)
    gap=float((rhythm.get('expert_gaps') or {}).get('median') or 9)
    block=max(.5,min(60,block));gap=max(.5,min(60,gap))
    clips=[]; t=3; i=0
    while t<length and len(clips)<3000:
        # Intervalo sem inserção é proposital: mantém visível a faixa base do expert.
        block_end=min(length,t+block*rng.uniform(.9,1.1))
        while t<block_end-.25 and len(clips)<3000:
            v=pool[i%len(pool)]
            duration=min(cadence*rng.uniform(.75,1.3),float(v['duration']),block_end-t)
            if duration<=.25:break
            clips.append({'path':v['path'],'name':v['name'],'start':t,'duration':duration,'source_start':0})
            t+=duration;i+=1
        t=block_end+gap*rng.uniform(.9,1.1)
    return {'clips':clips,'style':style,'selection':selection,'note':'Seleção aleatória com histórico para a primeira inserção. Cadência estrutural do perfil; revise a relevância das imagens.'}
