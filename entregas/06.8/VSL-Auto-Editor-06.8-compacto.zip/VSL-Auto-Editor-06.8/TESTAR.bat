@echo off
cd /d "%~dp0"
if exist "runtime\ffmpeg\ffmpeg.exe" set "PATH=%CD%\runtime\ffmpeg;%PATH%"
if exist .venv\Scripts\python.exe (
 .venv\Scripts\python.exe -m unittest discover -s tests -v
) else (
 python -m unittest discover -s tests -v
)
pause
