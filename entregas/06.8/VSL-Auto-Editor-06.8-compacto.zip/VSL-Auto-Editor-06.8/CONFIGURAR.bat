@echo off
setlocal
cd /d "%~dp0"
set "VSL_BOOT_PYTHON=%~2"
if not defined VSL_BOOT_PYTHON set "VSL_BOOT_PYTHON=python"
"%VSL_BOOT_PYTHON%" -c "import sys" >nul 2>nul
if errorlevel 1 if exist "%USERPROFILE%\AppData\Local\Programs\Python\Python313\python.exe" set "VSL_BOOT_PYTHON=%USERPROFILE%\AppData\Local\Programs\Python\Python313\python.exe"
"%VSL_BOOT_PYTHON%" -c "import sys" >nul 2>nul
if errorlevel 1 if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" set "VSL_BOOT_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist .venv\Scripts\python.exe "%VSL_BOOT_PYTHON%" -m venv .venv
if errorlevel 1 goto erro
.venv\Scripts\python.exe -m pip install "Pillow>=10,<13" "numpy>=2,<3"
if errorlevel 1 goto erro
echo Editor configurado. Execute INICIAR.bat.
if not "%~1"=="auto" pause
exit /b 0
:erro
echo Falha ao configurar. Verifique Python e conexao com a internet.
if not "%~1"=="auto" pause
exit /b 1
