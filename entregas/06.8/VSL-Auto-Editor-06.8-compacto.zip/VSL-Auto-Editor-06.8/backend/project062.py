"""Read one project folder. Never alter source media or reference drafts."""
import json
from pathlib import Path
from catalog import scan
from database import save

def load_project(folder, scan_audio, music_file, sfx_file):
    root = Path(folder).expanduser().resolve()
    if not folder or not root.is_dir():
        raise ValueError('Informe a pasta do projeto.')
    items = scan(root,exclude_reference=True)
    # Reference clips teach style; they must not become editable B-roll.
    items = [x for x in items if not ({'exemplos', 'referencias', 'referências'} & {part.lower() for part in Path(x['relative_path']).parts[:-1]})]
    bases = [x for x in items if x['category']=='especialista' and not x['error'] and x.get('has_audio')]
    if not bases:
        raise ValueError('Nenhuma base com áudio encontrada. Use especialista/base1.mp4, base2.mp4…')
    # Retain locally imported media and synthesized sounds referenced by saved plans.
    from database import load
    generated=(Path(__file__).resolve().parents[1]/'data/generated').resolve()
    imports=[x for x in load() if Path(x['path']).resolve().is_relative_to(generated) and Path(x['path']).is_file()]
    items+=imports
    save(items, merge=False)
    warnings=[]
    def audio(kind, destination):
        result=[]
        for item in items:
            if item['category']!=kind or item['error']:continue
            try:
                # Analyze this file only, avoiding duplicate scans of nested folders.
                from editor06 import audio_analysis
                result.append({'path':item['path'],'name':item['name'],'duration':item['duration'],**audio_analysis(item['path'],split=True)})
            except Exception as exc:warnings.append(item['name']+': '+str(exc))
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        return result
    music=audio('musicas',music_file); sfx=audio('transicoes',sfx_file)
    references=next((str(d) for d in root.iterdir() if d.is_dir() and d.name.lower() in ('exemplos','referencias','referências')),None)
    profile=None
    candidates=sorted(root.rglob('perfil_estilo_corrigido.json'),key=lambda p:(len(p.relative_to(root).parts),str(p)))
    if candidates:
        try:
            from style_engine import read_profile
            read_profile(str(candidates[0]))
            profile=str(candidates[0])
            if len(candidates)>1:warnings.append('Mais de um perfil encontrado; usado '+str(candidates[0].relative_to(root)))
        except Exception as exc:warnings.append('Perfil da pasta inválido; será usado o incluído no editor. '+str(exc))
    saved_file=root/'vsl-plan-06.8.json';saved=None
    if saved_file.exists():
        try:saved=json.loads(saved_file.read_text(encoding='utf8'))
        except (ValueError,OSError):warnings.append('Plano salvo inválido; prepare novamente ou abra um JSON válido.')
    # Generated sounds are local assets, separate from the user source folders.
    if saved:
        sound_paths={c['path'] for c in saved.get('sfxEvents',[])}
        from catalog import probe
        for p in sound_paths:
            path=Path(p).resolve()
            if path.is_relative_to(generated) and path.is_file() and p not in {x['path'] for x in sfx}:
                info=probe(path)
                if not info.get('error'):sfx.append({'path':p,'name':path.name,'duration':info['duration'],'regions':[]})
        sfx_file.write_text(json.dumps(sfx,ensure_ascii=False,indent=2),encoding='utf8')
    return {'savedPlan':saved,'items':items,'music':music,'sfx':sfx,'references':references,'profile':profile,'warnings':warnings,'folder':str(root)}
