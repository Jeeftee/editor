"""06.8 local motion presets, synthesized sounds, imported images and coverage review."""
import base64, copy, io, json, math, re, uuid, wave
from pathlib import Path
import numpy as np
from PIL import Image
from editor06 import ROOT, finite

MOTIONS=('none','fade','slide','pop','pulse','rotate','bounce','zoom')
KINDS=('arrow','ring','box','text','lowerthird','badge','counter','particles','progress')

def motion_values(entry, elapsed):
    kind=entry.get('motion','none')
    if kind not in MOTIONS:raise ValueError('Motion inválido.')
    elapsed=max(0,elapsed+finite(entry.get('motion_offset')))
    ease=1-(1-min(1,elapsed/.5))**3
    out={'scale':1.,'x':0.,'y':0.,'opacity':1.,'rotation':0.}
    if kind=='fade':out['opacity']=ease
    elif kind=='slide':out['x']=-.25*(1-ease);out['opacity']=ease
    elif kind=='pop':out['scale']=.4+.6*ease;out['opacity']=ease
    elif kind=='pulse':out['scale']=1+.06*math.sin(elapsed*math.pi*4)
    elif kind=='rotate':out['rotation']=elapsed*45
    elif kind=='bounce':out['y']=-.035*abs(math.sin(elapsed*math.pi*2))
    elif kind=='zoom':out['scale']=1+.12*min(1,elapsed/max(.1,entry.get('motion_duration',entry.get('duration',3))))
    return out

def synthesize(payload):
    preset=payload.get('preset','whoosh');duration=finite(payload.get('duration'),.7)
    if preset not in ('whoosh','impact','chime','riser','click'):raise ValueError('Preset sonoro inválido.')
    if not .1<=duration<=5:raise ValueError('Som local: duração entre 0,1 e 5 segundos.')
    rate=48000;t=np.arange(round(rate*duration))/rate;p=t/duration
    rng=np.random.default_rng(68);noise=rng.uniform(-1,1,len(t))
    if preset=='whoosh':samples=noise*np.sin(math.pi*p)**2*.45
    elif preset=='impact':samples=(np.sin(2*math.pi*(85*t-25*t*t/duration))+noise*.35)*np.exp(-8*p)*.6
    elif preset=='chime':samples=(np.sin(2*math.pi*880*t)+.5*np.sin(2*math.pi*1320*t))*np.exp(-4*p)*.4
    elif preset=='riser':samples=(np.sin(2*math.pi*(140*t+1000*t*t/duration))*.4+noise*.15)*p
    else:samples=(noise*.5+np.sin(2*math.pi*1600*t)*.2)*np.exp(-35*p)
    samples*=np.minimum(1,t/.005)*np.minimum(1,(duration-t)/.025)
    dest=ROOT/'data/generated/sounds'/f'{preset}_{round(duration*1000)}.wav';dest.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(dest),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes((np.clip(samples,-.9,.9)*32767).astype('<i2').tobytes())
    return {'path':str(dest.resolve()),'name':preset+' · local','duration':len(t)/rate,'audible_start_s':0,'peak_s':float(t[np.argmax(np.abs(samples))]),'regions':[],'generated':True}

def import_image(payload):
    from catalog import scan
    from database import save
    raw=base64.b64decode(payload.get('data',''),validate=True)
    if len(raw)>6_000_000:raise ValueError('Imagem acima de 6 MB. Use a pasta de inserções para arquivos maiores.')
    with Image.open(io.BytesIO(raw)) as img:
        if img.width*img.height>30_000_000:raise ValueError('Imagem grande demais.')
        img.load();fmt=img.format
        if fmt not in ('PNG','JPEG','WEBP','BMP'):raise ValueError('Use PNG, JPG, WEBP ou BMP.')
    name=Path(str(payload.get('name','imagem'))).stem
    name=re.sub(r'[^\w .-]','_',name)[:70] or 'imagem'
    folder=ROOT/'data/generated/images';folder.mkdir(parents=True,exist_ok=True)
    path=folder/(uuid.uuid4().hex[:8]+'_'+name+{'PNG':'.png','JPEG':'.jpg','WEBP':'.webp','BMP':'.bmp'}[fmt]);path.write_bytes(raw)
    items=scan(folder,'insercoes');save(items,merge=True)
    return next(x for x in items if x['path']==str(path.resolve()))

def validate_additions(plan,duration):
    if plan.get('resolution','fullhd') not in ('hd','fullhd'):raise ValueError('Resolução inválida.')
    for c in plan.get('clips',[])+plan.get('bases',[]):
        motion_values(c,0)
        if c.get('motion','none')!='none' and c in plan.get('bases',[]):raise ValueError('Motion do especialista não é automático. Aplique motion às inserções.')
        if finite(c.get('motion_offset'))<0 or finite(c.get('motion_duration'),c.get('duration',3))<=0:raise ValueError('Tempos de motion inválidos.')
    groups=plan.get('compounds',[])
    if not isinstance(groups,list) or len(groups)>100:raise ValueError('Compostos inválidos.')
    all_items=plan.get('clips',[])+plan.get('effects',[])+plan.get('captions',[])+plan.get('musicClips',[])+plan.get('sfxEvents',[])
    group_ids=set()
    for group in groups:
        if not isinstance(group,dict) or not isinstance(group.get('id'),str) or group['id'] in group_ids:raise ValueError('Composto inválido.')
        group_ids.add(group['id'])
        if not isinstance(group.get('name'),str) or not group['name'].strip():raise ValueError('Nome de composto inválido.')
    for item in all_items:
        if item.get('compoundId') and item['compoundId'] not in group_ids:raise ValueError('Referência de composto inválida.')

def validate_music(plan,catalog,duration):
    if not plan.get('musicManual'):return
    end={}
    for c in sorted(plan.get('musicClips',[]),key=lambda c:finite(c.get('start'))):
        item=next((x for x in catalog if x['path']==c.get('path')),None)
        a=finite(c.get('start'));d=finite(c.get('duration'));src=finite(c.get('source_start'));layer=c.get('lane',0)
        if not item or layer not in (0,1) or a<end.get(layer,0)-.002 or d<.04 or src<0 or src+d>item['duration']+.002 or a+d>duration+.002 or not 0<=finite(c.get('gain'),.3)<=2:raise ValueError('Trecho de música inválido ou sobreposto na mesma faixa.')
        for key in ('fade_in','fade_out'):
            if not 0<=finite(c.get(key))<=d:raise ValueError('Fade de música inválido.')
        end[layer]=a+d

def coverage(plan,catalog):
    from integrations import tokens
    from editor06 import validate
    duration=validate(plan,catalog);indexed={x['path']:x for x in catalog};records=[];covered=[]
    for c in sorted(plan.get('clips',[]),key=lambda x:x['start']):
        text=' '.join(x['text'] for x in plan.get('captions',[]) if x['start']<c['start']+c['duration'] and x['end']>c['start'])
        item=indexed[c['path']];matched=tokens(text)&tokens(item.get('name','')+' '+item.get('relative_path',''))
        records.append({'name':c.get('name',item['name']),'start':c['start'],'end':c['start']+c['duration'],'text':text,'matched':sorted(matched),'status':'correspondência por nome' if matched else 'provisório · revisar imagem'})
        covered.append((c['start'],c['start']+c['duration']))
    gaps=[];cursor=0
    for a,b in sorted(covered):
        if a>cursor+.002:gaps.append({'start':cursor,'end':a})
        cursor=max(cursor,b)
    if cursor<duration-.002:gaps.append({'start':cursor,'end':duration})
    return {'duration':duration,'records':records,'gaps':gaps,'scope':'Todas as inserções; correspondência local por nomes, não análise visual. Espaços sem inserção mostram o especialista.'}

def validate_sounds(plan,catalog,duration):
    items=plan.get('sfxEvents',[])
    if not isinstance(items,list) or len(items)>3000:raise ValueError('Lista de sons inválida.')
    for c in items:
        item=next((x for x in catalog if x['path']==c.get('path')),None)
        start=finite(c.get('start'));length=finite(c.get('duration'));source=finite(c.get('source_start'));gain=finite(c.get('gain'),.3)
        if not item or start<0 or length<.04 or start+length>duration+.002 or source<0 or source+length>item['duration']+.002 or not 0<=gain<=2:raise ValueError('Som fora da biblioteca ou com tempos/volume inválidos.')
