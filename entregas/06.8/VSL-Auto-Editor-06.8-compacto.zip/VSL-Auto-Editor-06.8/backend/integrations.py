"""Local video-use adapter and optional pinned HyperFrames renderer."""
import copy, hashlib, html, importlib.util, json, os, re, shutil, subprocess, sys, threading, types, unicodedata, uuid
from pathlib import Path
from urllib.parse import quote
from editor06 import ROOT, JOBS, validate, caption_groups, finite
from catalog import probe, IMAGES

CACHE=ROOT/'data/integrations'
GENERATED=ROOT/'data/generated'
HF_VERSION='0.8.148'

def upstream(name):
    path=ROOT/'third_party/video_use'/f'{name}.py'
    spec=importlib.util.spec_from_file_location('vsl_upstream_'+name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    if name=='timeline_view':
        # Windows sandbox tokens cannot reopen Python 3.13 private temp directories.
        # Supply private, uniquely named work folders with inherited workspace ACLs.
        class WorkspaceTemp:
            def __init__(self):self.path=CACHE/('tmp_'+uuid.uuid4().hex);self.path.mkdir(parents=True)
            def __enter__(self):return str(self.path)
            def __exit__(self,*args):
                if self.path.resolve().parent==CACHE.resolve():shutil.rmtree(self.path)
        def temp_file(suffix='',delete=False):
            CACHE.mkdir(parents=True,exist_ok=True);return (CACHE/('tmp_'+uuid.uuid4().hex+suffix)).open('wb')
        module.tempfile=types.SimpleNamespace(TemporaryDirectory=WorkspaceTemp,NamedTemporaryFile=temp_file)
    return module

def signature(plan, extra=None):
    files=[]
    for c in plan.get('bases',[])+plan.get('clips',[]):
        p=Path(c['path']);s=p.stat();files.append((str(p.resolve()),s.st_size,s.st_mtime_ns))
    return hashlib.sha256(json.dumps({'version':1,'plan':plan,'files':files,'extra':extra},sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:24]

def run_job(fn):
    job=uuid.uuid4().hex;JOBS[job]={'status':'running','progress':'Preparando integração local...'}
    def work():
        try:JOBS[job]={'status':'done',**fn(lambda text:JOBS[job].update(progress=text))}
        except Exception as e:JOBS[job]={'status':'error','error':str(e)}
    threading.Thread(target=work,daemon=True).start()
    return {'job':job}

def imported_transcript(payload,catalog):
    base=payload.get('base',{});validate({'bases':[dict(base,start=0)],'clips':[]},catalog)
    # Accept only a full catalogued specialist base, with its actual timeline offset.
    offset=finite(base.get('start'));duration=finite(base['duration']);raw=payload.get('transcript',{})
    words=[]
    for w in raw.get('words',[]):
        if w.get('type','word')!='word':continue
        a=finite(w.get('start'));b=finite(w.get('end'));text=str(w.get('text',w.get('word',''))).strip()
        if not text:continue
        if a<0 or b<=a or b>duration+.05:raise ValueError('Timestamp da transcrição fora da base selecionada.')
        words.append({'word':text,'start':a+offset,'end':b+offset})
    if not words:raise ValueError('JSON sem palavras e timestamps. Importe a saída Scribe do video-use.')
    words.sort(key=lambda w:w['start'])
    return {'captions':caption_groups([{'words':words}]),'source':'video-use/Scribe','base_path':base['path']}

def tokens(text):
    text=unicodedata.normalize('NFKD',str(text)).encode('ascii','ignore').decode().lower()
    stop={'para','como','mais','uma','com','por','que','dos','das','seu','sua','isso','esta','esse','voce','the','and','mp4','mov','png','jpg','base'}
    return {w for w in re.findall(r'[a-z0-9]+',text) if len(w)>2 and w not in stop}

def suggest_by_transcript(plan,catalog):
    validate(plan,catalog)
    if not plan.get('captions'):raise ValueError('Gere legendas ou importe a transcrição antes de sugerir inserções.')
    result=copy.deepcopy(plan['clips']);pool=[v for v in catalog if v.get('category')=='insercoes' and not v.get('error')]
    changes=[];previous=None
    for index,clip in enumerate(sorted(result,key=lambda c:c['start'])):
        if index==0 and plan.get('preserveOpeningRandom'):
            previous=clip['path'];continue
        text=' '.join(c['text'] for c in plan['captions'] if c['start']<clip['start']+clip['duration'] and c['end']>clip['start'])
        wanted=tokens(text);ranked=[]
        for v in pool:
            if Path(v['path']).suffix.lower() not in IMAGES and v.get('duration',0)<clip['duration']:continue
            matched=wanted & tokens(v.get('name','')+' '+v.get('relative_path',''))
            if matched:ranked.append((len(matched),v['path']!=previous,v,matched))
        if ranked:
            _,_,v,matched=max(ranked,key=lambda x:(x[0],x[1],x[2]['path']))
            if v['path']!=clip['path']:
                changes.append({'start':clip['start'],'from':clip['name'],'to':v['name'],'keywords':sorted(matched)})
                clip.update(path=v['path'],name=v['name'],source_start=0,layout='full');clip.pop('crop',None)
            previous=v['path']
    validate({**plan,'clips':result},catalog)
    return {'clips':result,'changes':changes,'method':'Correspondência local de palavras da fala com nomes das inserções; não é compreensão visual por IA.'}

def asset_url(path):
    return '/api/integrations/asset?file='+quote(Path(path).resolve().relative_to(ROOT/'data').as_posix())

def asset_path(relative):
    path=(ROOT/'data'/relative).resolve()
    if not path.is_relative_to((ROOT/'data/integrations').resolve()) or path.suffix.lower() not in ('.png','.json','.md') or not path.is_file():raise ValueError('Artefato indisponível.')
    return path

def review(plan,catalog,progress=lambda _:None,panels=True):
    validate(plan,catalog)
    key=signature(plan,{'panels':panels});folder=CACHE/key;folder.mkdir(parents=True,exist_ok=True);report_file=folder/'review.json'
    if report_file.exists():return {**json.loads(report_file.read_text(encoding='utf-8')),'cached':True}
    pack=upstream('pack_transcripts');words=[]
    for c in sorted(plan.get('captions',[]),key=lambda c:c['start']):
        text=c['text'].split();span=c['end']-c['start']
        lexical=c.get('words',[])
        if lexical and ' '.join(w['word'].strip() for w in lexical)==c['text'].strip():
            words.extend({'type':'word','text':w['word'],'start':w['start'],'end':w['end'],'speaker_id':'specialist'} for w in lexical)
        else:
            for i,w in enumerate(text):words.append({'type':'word','text':w,'start':c['start']+span*i/len(text),'end':c['start']+span*(i+1)/len(text),'speaker_id':'specialist'})
    phrases=pack.group_into_phrases(words,.5)
    packed=pack.render_markdown([('Narração integral do especialista',sum(b['duration'] for b in plan['bases']),phrases)],.5)
    (folder/'takes_packed.md').write_text(packed,encoding='utf-8')
    (folder/'transcript.json').write_text(json.dumps({'words':words},ensure_ascii=False),encoding='utf-8')
    duration=sum(b['duration'] for b in plan['bases']);warnings=[]
    if any(c.get('timing')!='word' or not c.get('words') for c in plan.get('captions',[])):warnings.append('Alguns tempos por palavra são interpolados; revise a sincronização na mídia.')
    if not words:warnings.append('Sem transcrição: revisão de sincronização lexical indisponível.')
    for c in plan.get('captions',[]):
        if len(c['text'].split())>3:warnings.append(f"Legenda em {c['start']:.2f}s tem mais de três palavras.")
        if c['end']-c['start']<.15:warnings.append(f"Legenda em {c['start']:.2f}s pode ser curta demais para leitura.")
    events=sorted(plan.get('sfxEvents',[]),key=lambda e:e['start'])
    for a,b in zip(events,events[1:]):
        if a['start']+a['duration']>b['start']+.001:warnings.append(f"Efeitos sobrepostos em {b['start']:.2f}s.")
    panel_records=[]
    if panels:
        try:timeline=upstream('timeline_view')
        except ImportError:raise ValueError('Execute INSTALAR_INTEGRACOES.bat para instalar Pillow e NumPy.')
        # Exact upstream visual tool, no LLM or cloud upload. Inspect both sides of up to 12 boundaries.
        times=sorted({round(c['start'],4) for c in plan['clips']}|{round(c['start']+c['duration'],4) for c in plan['clips']})
        for i,t in enumerate(times[:12]):
            progress(f'Inspecionando junção {i+1}/{min(12,len(times))} em {t:.2f}s')
            for side,point in [('antes',max(0,t-.05)),('depois',min(duration-.05,t+.05))]:
                visual=next((c for c in plan['clips'] if c['start']<=point<c['start']+c['duration']),None)
                visual=visual or next((b for b in plan['bases'] if b['start']<=point<b['start']+b['duration']),None)
                if not visual or Path(visual['path']).suffix.lower() in IMAGES:continue
                source=point-visual['start']+visual.get('source_start',0);length=probe(visual['path'])['duration']
                a=max(0,source-.25);b=min(length-.025,source+.25)
                if b-a<.04:continue
                out=folder/f'cut_{i:03d}_{side}.png'
                timeline.render_timeline(Path(visual['path']),a,b,out,n_frames=3,transcript=None)
                panel_records.append({'time':t,'side':side,'source':visual['name'],'url':asset_url(out)})
        if len(times)>12:warnings.append('Painéis limitados às primeiras 12 junções; as demais exigem revisão.')
    report={'cached':False,'duration':duration,'voice_preserved':True,'checks':{'category_and_bounds':'passed','single_broll_lane':'passed','full_narration':'passed'},'warnings':warnings,'panels':panel_records,'packed_url':asset_url(folder/'takes_packed.md'),'report_url':asset_url(report_file),'packed_text':packed,'phrases':phrases,'scope':'Painéis das mídias de origem. Não verificam o shader nativo, a composição final nem comprovam ausência de pops de áudio.'}
    report_file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report

def hf_cli():
    cli=Path(os.environ.get('VSL_HYPERFRAMES_CLI',ROOT/'runtime/node_modules/hyperframes/bin/hyperframes.mjs'))
    if not cli.is_file() or not shutil.which('node'):raise ValueError('Execute INSTALAR_HYPERFRAMES.bat. Requer Node.js 22+ e FFmpeg.')
    return cli

def create_graphic(payload):
    title=str(payload.get('title','')).strip()[:120];subtitle=str(payload.get('subtitle','')).strip()[:180]
    if not title:raise ValueError('Informe o título da inserção.')
    duration=finite(payload.get('duration'),3)
    if not 1<=duration<=15:raise ValueError('Duração da animação: 1 a 15 segundos.')
    color=str(payload.get('color','#8b5cf6'))
    if not re.fullmatch(r'#[0-9a-fA-F]{6}',color):raise ValueError('Cor inválida.')
    cli=hf_cli();gsap=cli.parents[2]/'gsap/dist/gsap.min.js'
    if not gsap.is_file():raise ValueError('GSAP local não encontrado. Execute INSTALAR_HYPERFRAMES.bat novamente.')
    key=hashlib.sha256(json.dumps([title,subtitle,duration,color,HF_VERSION]).encode()).hexdigest()[:24]
    folder=GENERATED/('hf_'+key);folder.mkdir(parents=True,exist_ok=True)
    shutil.copy2(gsap,folder/'gsap.min.js')
    doc='''<!doctype html><html><head><meta charset="utf-8"><style>
    *{box-sizing:border-box}body{margin:0;background:#101827;color:white;font-family:Arial,sans-serif}
    #stage{position:relative;width:1080px;height:1920px;overflow:hidden;background:radial-gradient(circle at 50% 25%,COLOR,#101827 70%)}
    #card{position:absolute;left:80px;right:80px;top:620px;text-align:center}h1{font-size:92px;line-height:1.08;overflow-wrap:anywhere;margin:0 0 42px}
    p{font-size:44px;line-height:1.3;overflow-wrap:anywhere}#bar{height:12px;background:white;width:180px;margin:60px auto;border-radius:6px}
    </style></head><body><div id="stage" data-composition-id="vsl-insertion" data-width="1080" data-height="1920" data-duration="DURATION" data-fps="24">
    <div id="card" class="clip" data-start="0" data-duration="DURATION" data-track-index="0"><h1>TITLE</h1><p>SUBTITLE</p><div id="bar"></div></div></div>
    <script src="gsap.min.js"></script><script>
    const tl=gsap.timeline({paused:true});tl.from('#card',{opacity:0,y:70,scale:.94,duration:.45},0).from('#bar',{scaleX:0,duration:.5},.15).to('#card',{opacity:0,y:-35,duration:.3},DURATION-.3);
    window.__timelines={'vsl-insertion':tl};</script></body></html>'''
    doc=doc.replace('COLOR',color).replace('DURATION',str(duration)).replace('SUBTITLE',html.escape(subtitle)).replace('TITLE',html.escape(title))
    (folder/'index.html').write_text(doc,encoding='utf-8')
    (folder/'source.json').write_text(json.dumps({'title':title,'subtitle':subtitle,'duration':duration,'color':color,'hyperframes':HF_VERSION},ensure_ascii=False),encoding='utf-8')
    return folder

def render_graphic(payload,progress=lambda _:None):
    folder=create_graphic(payload);out=folder/'insercao.mp4'
    if out.is_file() and probe(out)['duration']>=finite(payload.get('duration'),3)-.1:return {'path':str(out),'source_project':str(folder),'cached':True}
    cli=hf_cli();env=dict(os.environ,HYPERFRAMES_NO_TELEMETRY='1',HEYGEN_CONFIG_DIR=str(ROOT/'data/hf_config'),HYPERFRAMES_EXTRACT_CACHE_DIR=str(ROOT/'data/hf_frames'))
    for command in ([str(shutil.which('node')),str(cli),'lint',str(folder)],[str(shutil.which('node')),str(cli),'render',str(folder),'--workers','1','--fps','24','--quality','draft','--output',str(out)]):
        progress('Validando composição HyperFrames...' if 'lint' in command else 'Renderizando inserção HyperFrames...')
        p=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=600,env=env)
        if p.returncode:raise ValueError('HyperFrames falhou: '+(p.stderr or p.stdout)[-1800:])
    if not out.is_file():raise ValueError('HyperFrames não produziu o vídeo.')
    probe(out)
    return {'path':str(out),'source_project':str(folder),'cached':False}
