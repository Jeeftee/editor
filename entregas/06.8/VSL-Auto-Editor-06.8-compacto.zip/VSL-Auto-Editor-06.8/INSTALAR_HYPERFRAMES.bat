@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto fail
set HYPERFRAMES_NO_TELEMETRY=1
call npm install --prefix runtime hyperframes@0.8.148 gsap@3.14.2 --cache runtime\npm-cache --no-audit --no-fund
if errorlevel 1 goto fail
node runtime\node_modules\hyperframes\bin\hyperframes.mjs browser ensure
if errorlevel 1 goto fail
echo HyperFrames instalado. Execute INICIAR.bat.
pause
exit /b 0
:fail
echo A instalacao falhou. Requer Node.js 22+, internet e acesso ao Chrome.
pause
exit /b 1
