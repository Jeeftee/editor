import json
import subprocess
from pathlib import Path
import threading, uuid
from concurrent.futures import ThreadPoolExecutor

PROBE_CACHE=Path(__file__).resolve().parents[1]/'data/media_probe_cache.json'
CACHE_LOCK=threading.Lock()

EXTENSIONS = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
IMAGES = {'.png', '.jpg', '.jpeg', '.webp', '.bmp'}
AUDIO = {'.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac'}

def category_for(path, root, requested=None):
    # Audio folders win even when their MP4 happens to be named base1.mp4.
    parts = {p.lower() for p in path.relative_to(root).parts[:-1]} | {root.name.lower()}
    if parts & {'musicas', 'músicas', 'music'}: return 'musicas'
    if parts & {'transicoes', 'transições', 'sfx'}: return 'transicoes'
    if requested in ('especialista', 'insercoes', 'musicas', 'transicoes'): return requested
    if parts & {'bases', 'especialista', 'expert'}: return 'especialista'
    import re
    if re.match(r'^base[\s_-]*\d+(?=\D|$)', path.name, re.I): return 'especialista'
    return 'insercoes'

def probe(path):
    try:
        proc = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height', '-of', 'json', str(path)], capture_output=True, text=True, timeout=20, check=True)
        data = json.loads(proc.stdout)
        stream = next((s for s in data.get('streams', []) if s.get('codec_type') == 'video'), {})
        duration=float(data.get('format', {}).get('duration', 0))
        if Path(path).suffix.lower() in IMAGES:duration=5.0
        return {'duration': duration, 'width': stream.get('width'), 'height': stream.get('height'), 'has_audio': any(x.get('codec_type')=='audio' for x in data.get('streams', [])), 'error': None}
    except Exception as exc:
        return {'duration': None, 'width': None, 'height': None, 'error': str(exc)[:250]}

def scan(folder, category=None, exclude_reference=False):
    root = Path(folder).expanduser().resolve()
    if not root.is_dir():
        raise ValueError('Pasta não encontrada.')
    paths=[]
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in EXTENSIONS | IMAGES | AUDIO:
            continue
        if exclude_reference and {p.lower() for p in path.relative_to(root).parts[:-1]} & {'exemplos','referencias','referências'}:continue
        paths.append(path)
    try:cache=json.loads(PROBE_CACHE.read_text(encoding='utf-8'))
    except (OSError,ValueError):cache={}
    updates={}
    def inspect(path):
        relative = path.relative_to(root);stat=path.stat();signature=[stat.st_size,stat.st_mtime_ns]
        stored=cache.get(str(path),{})
        meta=stored['metadata'] if stored.get('signature')==signature else probe(path)
        if not meta.get('error'):updates[str(path)]={'signature':signature,'metadata':meta}
        purpose=category_for(path,root,category)
        if purpose in ('insercoes','especialista') and path.suffix.lower() in AUDIO:return None
        return {'path': str(path), 'name': path.name, 'category': purpose, 'relative_path': str(relative), 'size_mb': round(stat.st_size / 1048576, 2), **meta}
    with ThreadPoolExecutor(max_workers=4) as workers:
        items=[item for item in workers.map(inspect,paths) if item is not None]
    with CACHE_LOCK:
        try:current=json.loads(PROBE_CACHE.read_text(encoding='utf-8'))
        except (OSError,ValueError):current={}
        current.update(updates);PROBE_CACHE.parent.mkdir(parents=True,exist_ok=True)
        temp=PROBE_CACHE.with_suffix('.'+uuid.uuid4().hex+'.tmp');temp.write_text(json.dumps(current,ensure_ascii=False),encoding='utf-8');temp.replace(PROBE_CACHE)
    return items
