"""Explicit optional registration; preserve all existing index entries with backup."""
import json,os,shutil,time,uuid
from pathlib import Path

def register(folder,index_path):
    folder=Path(folder).resolve();index=Path(index_path).expanduser().resolve()
    if not (folder/'draft_content.json').is_file() or not (folder/'draft_meta_info.json').is_file():raise ValueError('Projeto exportado não encontrado.')
    if index.name!='root_meta_info.json' or not index.is_file():raise ValueError('Selecione root_meta_info.json do CapCut.')
    # Never register while the editor is running: its shutdown could overwrite the index.
    if os.name=='nt':
        import subprocess
        p=subprocess.run(['tasklist','/FI','IMAGENAME eq CapCut.exe','/FO','CSV','/NH'],capture_output=True,text=True,timeout=10)
        if p.returncode!=0:raise ValueError('Não foi possível verificar se o CapCut está fechado. O índice foi preservado; execute o editor em uma sessão do Windows com acesso à lista de processos.')
        if 'capcut.exe' in p.stdout.lower():raise ValueError('Feche o CapCut antes de registrar o projeto.')
    data=json.loads(index.read_text(encoding='utf-8-sig'));meta=json.loads((folder/'draft_meta_info.json').read_text(encoding='utf-8'))
    stores=data.get('all_draft_store')
    if not isinstance(stores,list):raise ValueError('Índice do CapCut incompatível.')
    if any(m.get('draft_id')==meta['draft_id'] for m in stores):return {'registered':True,'already_registered':True}
    backup=folder/('capcut_index_backup_'+time.strftime('%Y%m%d_%H%M%S')+'.json');shutil.copy2(index,backup)
    stores.insert(0,{**meta,'draft_json_file':(folder/'draft_content.json').as_posix(),'draft_timeline_materials_size':0,'streaming_edit_draft_ready':True})
    data['draft_ids']=len(stores)
    temp=index.parent/('vsl06_index_'+uuid.uuid4().hex+'.tmp')
    try:
        temp.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8');os.replace(temp,index)
    finally:
        if temp.exists():temp.unlink()
    return {'registered':True,'backup':str(backup)}
