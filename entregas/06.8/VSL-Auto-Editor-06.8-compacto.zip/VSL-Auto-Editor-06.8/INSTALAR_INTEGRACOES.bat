@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r requirements-integracoes.txt
if errorlevel 1 goto fail
echo Modulos de revisao video-use instalados. Execute INICIAR.bat.
pause
exit /b 0
:fail
echo A instalacao falhou. Verifique Python e acesso a internet.
pause
exit /b 1
