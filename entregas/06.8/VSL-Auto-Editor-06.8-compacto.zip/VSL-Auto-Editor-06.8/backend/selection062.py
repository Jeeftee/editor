"""Persistent shuffled opening choices; narration changes do not reset the bag."""
import hashlib
import json
import random
import threading
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
LOCK=threading.Lock()

def choose_opening(pool):
    paths=sorted({x['path'] for x in pool})
    if not paths:raise ValueError('Nenhuma inserção disponível.')
    signature=hashlib.sha256(json.dumps(paths,ensure_ascii=False).encode()).hexdigest()
    file=ROOT/'data/selection_history'/(signature+'.json')
    with LOCK:
        try:state=json.loads(file.read_text(encoding='utf-8'))
        except (OSError,ValueError):state={}
        allowed=set(paths)
        remaining=[p for p in state.get('remaining',[]) if p in allowed]
        if not remaining:
            remaining=paths.copy();random.SystemRandom().shuffle(remaining)
            if len(remaining)>1 and remaining[-1]==state.get('last'):
                remaining[0],remaining[-1]=remaining[-1],remaining[0]
        choice=remaining.pop()
        file.parent.mkdir(parents=True,exist_ok=True)
        temp=file.with_suffix('.'+uuid.uuid4().hex+'.tmp')
        temp.write_text(json.dumps({'remaining':remaining,'last':choice},ensure_ascii=False),encoding='utf-8');temp.replace(file)
    return next(x for x in pool if x['path']==choice),{'pool_size':len(paths),'remaining_openings':len(remaining),'method':'Aleatória, com histórico persistente e sem repetir a primeira inserção até percorrer o acervo.'}
