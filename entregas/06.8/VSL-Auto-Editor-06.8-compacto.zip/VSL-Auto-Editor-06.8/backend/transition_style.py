from reference062 import draft_files
"""Read CapCut transition metadata without guessing absent transitions."""
import json, re
from pathlib import Path
from collections import Counter

MAX_PROJECTS=200

def analyze(folder):
    root=Path(folder).expanduser().resolve()
    if not root.is_dir(): raise ValueError('Pasta de exemplos nao encontrada.')
    paths=[]
    for p in draft_files(root):
        if any('subdraft' in part.lower() for part in p.relative_to(root).parts):continue
        paths.append(p)
        if len(paths)>=MAX_PROJECTS:break
    counts=Counter(); durations=[]; examined=0; with_transitions=0; examples=[]
    for p in paths:
        try: d=json.loads(p.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):continue
        examined+=1
        transitions=d.get('materials',{}).get('transitions',[])
        if not isinstance(transitions,list):continue
        if transitions:with_transitions+=1
        for item in transitions:
            if not isinstance(item,dict):continue
            name=str(item.get('name') or item.get('type') or item.get('resource_id') or item.get('effect_id') or 'Sem nome')
            counts[name]+=1
            raw=item.get('duration',0)
            if isinstance(raw,(int,float)) and raw>0:durations.append(raw/1e6 if raw>10000 else raw)
            if len(examples)<20:examples.append({'name':name,'fields':list(item)[:15]})
    # Mapping is deliberately conservative: names are clues, not guaranteed equivalence.
    def family(s):
        s=s.lower()
        if any(w in s for w in ('fade','dissolve','cross','溶解','淡入','淡出','叠化')):return 'fade'
        if any(w in s for w in ('slide','push','swipe','滑动','推')):return 'slide'
        if any(w in s for w in ('zoom','scale','放大','缩小')):return 'zoom'
        return 'unknown'
    families=Counter()
    for name,n in counts.items():families[family(name)]+=n
    result={'projects_scanned':examined,'projects_with_transitions':with_transitions,'transitions_total':sum(counts.values()),'transition_names':dict(counts.most_common(40)),'preview_families':dict(families),'recognized_total':sum(n for k,n in families.items() if k!='unknown'),'unknown_total':families['unknown'],'duration_median_s':sorted(durations)[len(durations)//2] if durations else None,'examples':examples,'warning':('Sem transicoes identificadas nos JSONs fornecidos. O aplicativo nao pode inferir a distribuicao real.' if not counts else 'Familias de preview sao aproximacoes; a aparencia nativa deve ser conferida no CapCut.')}
    return result


def audit_native(folder):
    """Read-only inspection of native CapCut transition material and references.

    Never invent native IDs, never write to a user project.
    """
    root=Path(folder).expanduser().resolve()
    if not root.is_dir():raise ValueError('Pasta de exemplos nao encontrada.')
    projects=0;material_count=0;linked=0;unlinked=0;records=[];keys=Counter()
    for path in list(draft_files(root))[:200]:
        if any('subdraft' in x.lower() for x in path.relative_to(root).parts):continue
        try:data=json.loads(path.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):continue
        projects+=1
        mats=data.get('materials',{}).get('transitions',[])
        if not isinstance(mats,list):continue
        material_count+=len(mats)
        ids={m.get('id'):m for m in mats if isinstance(m,dict) and m.get('id')}
        for track in data.get('tracks',[]):
            for seg in track.get('segments',[]):
                for rid in seg.get('extra_material_refs',[]):
                    if rid in ids:linked+=1
        for m in mats:
            if not isinstance(m,dict):continue
            keys.update(m.keys())
            if len(records)<12:
                records.append({'name':str(m.get('name',''))[:100],'id_present':bool(m.get('id')),'resource_id_present':bool(m.get('resource_id')),'effect_id_present':bool(m.get('effect_id')),'fields':sorted(m.keys())[:25]})
    return {'projects':projects,'transition_materials':material_count,'segment_links':linked,'fields_frequency':dict(keys.most_common(25)),'samples':records,'native_export_ready':False,'warning':'Auditoria somente leitura. Referencias encontradas nao comprovam que o CapCut aceite transicoes nativas geradas. A exportacao usa materiais nativos; a aparencia final no CapCut 9.5 precisa ser validada.'}
