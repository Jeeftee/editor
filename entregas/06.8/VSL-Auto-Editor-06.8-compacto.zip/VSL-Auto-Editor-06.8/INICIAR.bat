@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\ffmpeg\ffmpeg.exe" set "PATH=%CD%\runtime\ffmpeg;%PATH%"
where ffmpeg >nul 2>nul
if errorlevel 1 goto faltou_ffmpeg
where ffprobe >nul 2>nul
if errorlevel 1 goto faltou_ffmpeg
set "VSL_PYTHON="
call :tentar "%CD%\.venv\Scripts\python.exe"
call :tentar "%USERPROFILE%\.codex\skills\editor-video\.venv\Scripts\python.exe"
call :tentar "%USERPROFILE%\AppData\Local\Programs\Python\Python313\python.exe"
call :tentar "python"
call :tentar "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not defined VSL_PYTHON (
 echo Python com Pillow e NumPy nao encontrado. Execute CONFIGURAR.bat.
 pause
 exit /b 1
)
if defined VSL_NO_BROWSER (
 "%VSL_PYTHON%" backend\main.py --no-browser
) else (
 "%VSL_PYTHON%" backend\main.py
)
if errorlevel 1 pause
exit /b
:tentar
if defined VSL_PYTHON exit /b
"%~1" -c "import PIL,numpy" >nul 2>nul
if not errorlevel 1 set "VSL_PYTHON=%~1"
exit /b
:faltou_ffmpeg
echo FFmpeg nao encontrado. Extraia todo o ZIP, incluindo runtime\ffmpeg.
pause
exit /b 1
