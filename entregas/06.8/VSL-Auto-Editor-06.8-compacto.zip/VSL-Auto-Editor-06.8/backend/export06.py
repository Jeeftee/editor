"""Export separate, editable CapCut drafts from observed reference schemas.

Native transition compatibility is not asserted without an actual CapCut test.
"""
import copy, json, os, shutil, struct, subprocess, time, uuid, zlib
from pathlib import Path
from catalog import probe, IMAGES
from editor06 import validate, library, sfx_events, finite
from visual063 import changed, bake

ROOT=Path(__file__).resolve().parents[1]
def uid():return str(uuid.uuid4()).upper()
def us(s):return round(float(s)*1e6)

def gradient_png(path):
    width,height=1080,1920;raw=bytearray()
    for y in range(height):
        alpha=max(0,round(110*(1-abs(y-height*.7)/45))) if abs(y-height*.7)<45 else 0
        raw.extend(b'\0'+bytes((0,0,0,alpha))*width)
    def chunk(kind,data):return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
    path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',width,height,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(bytes(raw)))+chunk(b'IEND',b''))

class Draft:
    def __init__(self,folder,name):
        self.folder=folder;self.name=name;self.assets=folder/'media';self.assets.mkdir()
        self.templates=json.loads((ROOT/'reference/templates.json').read_text(encoding='utf-8'))
        self.data=copy.deepcopy(self.templates['draft']);self.data.update(id=uid(),name=name,create_time=int(time.time()),update_time=int(time.time()))
        self.media={};self.transitions={m['resource_id']:m for m in library()};self.warnings=[]
        self.data['canvas_config']={'width':1080,'height':1920,'ratio':'9:16','background':None}
    def track(self,kind,name):
        t=copy.deepcopy(self.templates[kind]['track']);t.update(id=uid(),type=kind,name=name,is_default_name=False,segments=[],flag=0,attribute=0)
        self.data['tracks'].append(t);return t
    def material(self,kind,path):
        path=Path(path).resolve();key=(kind,str(path))
        if key in self.media:return self.media[key]
        info=probe(path)
        if info.get('error'):raise ValueError('Mídia inválida: '+str(path)+' '+str(info['error']))
        m=copy.deepcopy(self.templates[kind]['material']);m.update(id=uid(),unique_id=uuid.uuid4().hex,path=path.as_posix(),duration=us(info['duration']),source_platform=0)
        for field in ('resource_id','effect_id','third_resource_id','music_id','video_id','local_material_id','request_id','category_id','category_name','material_url','media_path','recognize_task_id','formula_id','team_id'):
            if field in m:m[field]=''
        if kind=='video':
            m.update(type='photo' if path.suffix.lower() in IMAGES else 'video',material_name=path.name,width=info['width'],height=info['height'],has_audio=bool(info.get('has_audio')),has_sound_separated=False)
            m['crop']={'upper_left_x':0.,'upper_left_y':0.,'upper_right_x':1.,'upper_right_y':0.,'lower_left_x':0.,'lower_left_y':1.,'lower_right_x':1.,'lower_right_y':1.}
            m['crop_ratio']='free';m['crop_scale']=1.
            for field in ('reverse_path','intensifies_path','cartoon_path','reverse_intensifies_path','intensifies_audio_path'):m[field]=''
            if 'video_algorithm' in m:
                m['video_algorithm']['algorithms']=[];m['video_algorithm']['path']=''
            if 'matting' in m:m['matting']['flag']=0;m['matting']['path']=''
        else:m.update(name=path.name,type='extract_music' if info.get('width') else 'music')
        self.data['materials'].setdefault('videos' if kind=='video' else 'audios',[]).append(m);self.media[key]=m;return m
    def segment(self,kind,track,material,start,duration,source=0,volume=1):
        s=copy.deepcopy(self.templates[kind]['segment']);s.update(id=uid(),material_id=material['id'],source_timerange={'start':us(source),'duration':us(duration)} if kind!='text' else None,target_timerange={'start':us(start),'duration':us(duration)},render_timerange={'start':0,'duration':0},extra_material_refs=[],keyframe_refs=[],common_keyframes=[],group_id='',speed=1.,reverse=False,is_loop=False,volume=volume,last_nonzero_volume=volume,desc='VSL06',visible=True,render_index=len(self.data['tracks'])-1,track_render_index=len(self.data['tracks'])-1)
        if kind!='audio':s['clip']={'scale':{'x':1.,'y':1.},'rotation':0.,'transform':{'x':0.,'y':0.},'flip':{'vertical':False,'horizontal':False},'alpha':1.}
        track['segments'].append(s);return s
    def fade(self,s,fade_in,fade_out):
        m=copy.deepcopy(self.templates['audio_fade']);m.update(id=uid(),fade_in_duration=us(fade_in),fade_out_duration=us(fade_out))
        self.data['materials'].setdefault('audio_fades',[]).append(m);s['extra_material_refs'].append(m['id'])
    def transition(self,left,right,edge):
        if not edge.get('resource_id'):return
        item=self.transitions.get(edge['resource_id'])
        if not item:raise ValueError('Transição fora da biblioteca de referências.')
        duration=min(finite(edge.get('duration'),.35),left['target_timerange']['duration']/2e6,right['target_timerange']['duration']/2e6)
        if duration<.04:return
        m=copy.deepcopy(item['material']);m.update(id=uid(),duration=us(duration))
        # Preserve real resource metadata. Missing cache files remain explicitly reported.
        try: available=not m.get('path') or Path(m['path']).exists()
        except OSError: available=False
        if not available:
            self.warnings.append('Recurso nativo não encontrado no cache: '+item['name']+' ('+item['resource_id']+'). Baixe a transição no CapCut.')
            m['path']=''
        self.data['materials']['transitions'].append(m);left['extra_material_refs'].append(m['id'])
    def extracted_audio(self,path):
        key=('wav',str(path))
        if key in self.media:return self.media[key]
        dest=self.assets/(uuid.uuid5(uuid.NAMESPACE_URL,str(Path(path).resolve())).hex+'.wav')
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-map','0:a:0','-vn','-c:a','pcm_s16le',str(dest)],capture_output=True,check=True,timeout=600)
        self.media[key]=dest;return dest
    def panel(self,s,m,panel,crop=None):
        clone=copy.deepcopy(m);clone['id']=uid();self.data['materials']['videos'].append(clone);s['material_id']=clone['id']
        target_h=.7 if panel=='expert' else .3
        w,h=clone['width'],clone['height'];top=(crop or {}).get('top',0);bottom=(crop or {}).get('bottom',1)
        if not 0<=top<bottom<=1:raise ValueError('Recorte split-screen inválido.')
        wanted=1080/(1920*target_h);content_h=h*(bottom-top);content_w=w
        if content_w/content_h>wanted:
            cw=content_h*wanted/w;ch=bottom-top
        else:cw=1.;ch=content_w/wanted/h
        x=.5;y=.36 if panel=='expert' else (top+bottom)/2
        y=max(top+ch/2,min(bottom-ch/2,y));left=x-cw/2;right=x+cw/2;a=y-ch/2;b=y+ch/2
        clone['crop']={'upper_left_x':left,'upper_left_y':a,'upper_right_x':right,'upper_right_y':a,'lower_left_x':left,'lower_left_y':b,'lower_right_x':right,'lower_right_y':b}
        # CapCut normalizes translation to half the canvas size.
        s['clip']['transform']['y']=.3 if panel=='expert' else -.7
        s['clip']['scale']={'x':1.,'y':1.}
    def captions(self,captions,settings=None):
        if not captions:return
        from captions063 import normalized as caption_style, states, content, font_path, FONTS, effective
        style=caption_style({'captionStyle':settings})
        track=self.track('text','VSL06 LEGENDAS')
        expanded=[{**state,'resolved_style':effective(c,style)} for c in captions for state in states(c,effective(c,style))]
        if any(s.get('estimated') for s in expanded) and (style['karaoke'] or style['animation']=='typewriter'):
            self.warnings.append('Algumas legendas não têm tempos por palavra; destaque/digitação usam tempos estimados. Revise a sincronização.')
        for c in expanded:
            style=c['resolved_style']
            m=copy.deepcopy(self.templates['text']['material']);m.update(id=uid(),recognize_text=c['text'],recognize_task_id='',words={'start_time':[],'end_time':[],'text':[]},current_words={'start_time':[],'end_time':[],'text':[]},fonts=[],font_path='',font_name='Arial',font_id='',font_resource_id='',group_id='',text_color='#ffffffff',font_size=10.,letter_spacing=0.,alignment=1)
            m['content']=json.dumps({'text':c['text'],'styles':[{'fill':{'content':{'render_type':'solid','solid':{'color':[1,1,1]}}},'font':{'path':'','id':''},'size':10.,'range':[0,len(c['text'])]}]},ensure_ascii=False)
            path=font_path(style['font'])
            m.update(font_name=FONTS[style['font']][0],font_path=path.as_posix() if path else '',font_size=style['size']/8.4,text_color=style['color'],border_color='#000000',border_width=style['stroke']/style['size'],background_color='#000000' if style['background'] else '',background_alpha=.72,background_style=1 if style['background'] else 0,background_round_radius=.15)
            m['content']=json.dumps(content(c,style),ensure_ascii=False)
            m['text_to_audio_ids']=[];m['relevance_segment']=[];m['subtitle_keywords']=None
            self.data['materials']['texts'].append(m)
            s=self.segment('text',track,m,c['start'],c['end']-c['start']);s['clip']['transform']['y']=1-2*style['y'];s['clip']['transform']['x']=2*style.get('x',.5)-1
            # Pulse represented with native, editable scale keyframes (observed schema).
            duration=s['target_timerange']['duration'];pulse=min(100000,duration//3)
            animation=style['animation']
            frames=[(0,.94),(pulse,1.04),(pulse*2,1.)] if animation=='pulse' else [(0,.7),(min(150000,duration),1.)] if animation=='pop' else [(0,.94),(duration,1.)] if animation=='zoom' else []
            for prop in ('KFTypeScaleX','KFTypeScaleY'):
                if frames:s['common_keyframes'].append({'id':uid(),'material_id':'','property_type':prop,'keyframe_list':[{'id':uid(),'time_offset':t,'values':[value],'curveType':'Line','left_control':{'x':0.,'y':0.},'right_control':{'x':0.,'y':0.},'string_value':'','graphID':''} for t,value in frames]})
    def write(self,duration,plan):
        self.data['duration']=us(duration)
        meta=copy.deepcopy(self.templates['meta']);meta.update(draft_id=self.data['id'],draft_name=self.name,draft_fold_path=self.folder.as_posix(),draft_root_path=self.folder.parent.as_posix(),tm_duration=us(duration),tm_draft_create=int(time.time()*1e6),tm_draft_modified=int(time.time()*1e6),draft_cover='',draft_materials=[],draft_materials_copied_info=[],draft_timeline_materials_size_=0)
        for filename,obj in [('draft_content.json',self.data),('draft_meta_info.json',meta),('vsl06_plan.json',plan)]:
            (self.folder/filename).write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
        report={'schema_checks':'passed','capcut_9_5_open_test':'pending','transitions_native':len(self.data['materials']['transitions']),'warnings':sorted(set(self.warnings)), 'native_boundary_strategy':'Transparent bridge clips on the B-roll track at expert gaps; acceptance and appearance must be checked in CapCut.'}
        (self.folder/'VALIDACAO.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        assert_draft(self.data)
        return report

def assert_draft(data):
    entries=[m for v in data['materials'].values() if isinstance(v,list) for m in v if isinstance(m,dict)]
    ids={m['id'] for m in entries}
    if len(ids)!=len(entries):raise ValueError('IDs de material duplicados.')
    for t in data['tracks']:
        for s in t['segments']:
            if s['material_id'] not in ids or any(r not in ids for r in s['extra_material_refs']):raise ValueError('Referência de material não resolvida.')
            r=s['target_timerange']
            if r['start']<0 or r['duration']<=0 or r['start']+r['duration']>data['duration']+2000:raise ValueError('Segmento fora do projeto.')

def export_plan(plan,catalog,music_catalog,sfx_catalog):
    duration=validate(plan,catalog)
    from studio068 import validate_music,validate_sounds
    validate_music(plan,music_catalog,duration)
    validate_sounds(plan,sfx_catalog,duration)
    music=next((m for m in music_catalog if m['path']==plan.get('musicPath')),None)
    if plan.get('musicPath') and not music:raise ValueError('Música fora da biblioteca de músicas.')
    for e in plan.get('sfxEvents',[]):
        m=next((m for m in sfx_catalog if m['path']==e['path']),None)
        if not m or finite(e.get('start'))<0 or finite(e.get('start'))>=duration or finite(e.get('source_start'))<0 or finite(e['duration'])<=0 or finite(e.get('source_start'))+finite(e['duration'])>m['duration']+.002 or not 0<=finite(e.get('gain'),.3)<=2:raise ValueError('Efeito sonoro inválido.')
    parent=Path(plan.get('project') or ROOT/'exports').expanduser().resolve()
    parent.mkdir(parents=True,exist_ok=True)
    # An existing CapCut draft can be used as an export parent; it is never overwritten.
    folder=parent/('VSL06_'+time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]);folder.mkdir()
    try:
        d=Draft(folder,folder.name)
        expert=d.track('video','VSL06 ESPECIALISTA')
        layer_count=max([int(c.get('layer',0)) for c in plan.get('clips',[])]+[0])+1
        broll_tracks=[d.track('video','VSL06 B-ROLL' if i==0 else 'VSL06 B-ROLL CAMADA '+str(i+1)) for i in range(layer_count)]
        voice=d.track('audio','VSL06 VOZ INTEGRAL')
        cuts=sorted(plan.get('clips',[]),key=lambda x:x['start']);splits=[c for c in cuts if c.get('layout')=='split']
        for base in plan['bases']:
            m=d.material('video',base['path']);wav=d.extracted_audio(base['path']);a=d.material('audio',wav)
            d.segment('audio',voice,a,base['start'],base['duration'],base.get('source_start',0),plan.get('voice',1))
            points=sorted({base['start'],base['start']+base['duration']}|{max(base['start'],min(base['start']+base['duration'],t)) for c in splits for t in (c['start'],c['start']+c['duration'])})
            for start,end in zip(points,points[1:]):
                if end-start<.04:continue
                s=d.segment('video',expert,m,start,end-start,start-base['start']+base.get('source_start',0),0)
                split_here=any(c['start']<=start+.002 and c['start']+c['duration']>=end-.002 for c in splits)
                if changed(base):
                    d.warnings.append('Enquadramento/máscara do trecho do especialista pré-composto; ajustes editáveis no VSL Auto Editor.')
                    entry={**base,'start':start,'duration':end-start,'source_start':start-base['start']+base.get('source_start',0)}
                    rendered=bake(entry,probe(base['path']),d.assets,'expert' if split_here else 'full')
                    s['material_id']=d.material('video',rendered)['id'];s['source_timerange']={'start':0,'duration':us(end-start)}
                elif split_here:d.panel(s,m,'expert')
        # Transparent clips bridge expert-only gaps, giving native transitions a real junction.
        def gap(track,a,b):
            for base in plan['bases']:
                start=max(a,base['start']);end=min(b,base['start']+base['duration'])
                if end-start<.04:continue
                s=d.segment('video',track,d.material('video',base['path']),start,end-start,start-base['start']+base.get('source_start',0),0);s['clip']['alpha']=0.
        for layer,track in enumerate(broll_tracks):
            cursor=0
            layer_edges=[e for e in plan.get('transitions',[]) if int(e.get('layer',0))==layer]
            for c in [c for c in cuts if int(c.get('layer',0))==layer]:
                if c['start']>cursor+.04:gap(track,cursor,c['start'])
                fade_in=next((min(e['duration'],c['duration']/2) for e in layer_edges if e.get('preview_kind')=='fade' and abs(e['time']-c['start'])<.002),0)
                fade_out=next((min(e['duration'],c['duration']/2) for e in layer_edges if e.get('preview_kind')=='fade' and abs(e['time']-c['start']-c['duration'])<.002),0)
                custom=changed(c) or fade_in or fade_out
                path=bake(c,probe(c['path']),d.assets,'broll' if c.get('layout')=='split' else 'full',fade_in,fade_out) if custom else c['path']
                m=d.material('video',path);s=d.segment('video',track,m,c['start'],c['duration'],0 if custom else c.get('source_start',0),0)
                if Path(c['path']).suffix.lower() not in IMAGES and probe(c['path']).get('has_audio'):
                    if not hasattr(d,'insert_audio'):d.insert_audio=d.track('audio','VSL06 ÁUDIO DAS INSERÇÕES')
                    wav=d.extracted_audio(c['path']);d.segment('audio',d.insert_audio,d.material('audio',wav),c['start'],c['duration'],c.get('source_start',0),plan.get('insertVolume',.3))
                if c.get('motion','none')!='none':
                    from motion068 import keyframes
                    s['common_keyframes']=keyframes(c);d.warnings.append('Motion exportado em keyframes editáveis; confira a interpolação no CapCut.')
                if custom:d.warnings.append('Máscara/efeito/posição pré-composto com transparência. Ajustes editáveis no VSL Auto Editor; no CapCut aparecem como mídia renderizada.')
                elif c.get('layout')=='split':d.panel(s,m,'broll',c.get('crop'))
                cursor=c['start']+c['duration']
            if duration>cursor+.04:gap(track,cursor,duration)
            edges={us(e['time']):e for e in layer_edges if e.get('resource_id')}
            ordered=sorted(track['segments'],key=lambda s:s['target_timerange']['start']);track['segments']=ordered
            for left,right in zip(ordered,ordered[1:]):
                point=left['target_timerange']['start']+left['target_timerange']['duration']
                if abs(point-right['target_timerange']['start'])<=2000 and point in edges:d.transition(left,right,edges[point])
        if splits:
            png=d.assets/'split_gradient.png';gradient_png(png);m=d.material('video',png);track=d.track('video','VSL06 DIVISÃO SPLIT')
            for c in splits:d.segment('video',track,m,c['start'],c['duration'],0,0)
        if plan.get('musicManual'):
            music_tracks=[d.track('audio','VSL06 MÚSICA A'),d.track('audio','VSL06 MÚSICA B')]
            for c in plan.get('musicClips',[]):
                path=d.extracted_audio(c['path']) if Path(c['path']).suffix.lower() in {'.mp4','.mov','.mkv','.webm','.avi'} else c['path']
                segment=d.segment('audio',music_tracks[c.get('lane',0)],d.material('audio',path),c['start'],c['duration'],c.get('source_start',0),c.get('gain',plan.get('music',.3)))
                d.fade(segment,c.get('fade_in',0),c.get('fade_out',0))
        elif music:
            path=d.extracted_audio(music['path']) if Path(music['path']).suffix.lower() in {'.mp4','.mov','.mkv','.webm','.avi'} else music['path']
            m=d.material('audio',path);trim=min(music.get('audible_start_s',0),max(0,music['duration']-.5));usable=music['duration']-trim
            overlap=min(finite(plan.get('musicCrossfade'),2.5),usable*.4);cycle=usable-overlap
            if cycle<.1:raise ValueError('Música curta demais.')
            tracks=[d.track('audio','VSL06 MÚSICA A'),d.track('audio','VSL06 MÚSICA B')]
            i=0;start=0
            while start<duration-.04:
                length=min(usable,duration-start);s=d.segment('audio',tracks[i%2],m,start,length,trim,plan.get('music',.3))
                d.fade(s,min(overlap,length/2) if i else 0,min(overlap,length/2));start+=cycle;i+=1
        events=sfx_events(plan,sfx_catalog);track=d.track('audio','VSL06 EFEITOS SONOROS') if events else None
        for e in events:
            length=min(e['duration'],duration-e['start'])
            if length<.04:continue
            path=d.extracted_audio(e['path']) if Path(e['path']).suffix.lower() in {'.mp4','.mov','.mkv','.webm','.avi'} else e['path']
            m=d.material('audio',path);s=d.segment('audio',track,m,e['start'],length,e.get('source_start',0),e.get('gain',plan.get('sfxVolume',.3)))
            d.fade(s,min(.08,length/4),min(.15,length/4))
        from effects064 import bake_effect
        if plan.get('effects'):
            effect_track=d.track('video','VSL06 EFEITOS GRÁFICOS')
            for effect in plan['effects']:
                path=bake_effect(effect,d.assets)
                d.segment('video',effect_track,d.material('video',path),effect['start'],effect['duration'],0,0)
        d.captions(plan.get('captions',[]),plan.get('captionStyle'))
        for i,t in enumerate(d.data['tracks']):
            for s in t['segments']:s['render_index']=i;s['track_render_index']=i
        if plan.get('resolution')=='hd':d.data['canvas_config'].update(width=720,height=1280)
        if plan.get('compounds'):d.warnings.append('Compostos do VSL preservados no plano; exportados como camadas separadas no CapCut, sem composto nativo.')
        report=d.write(duration,plan)
        return {'project':str(folder),'inserted':len(cuts),'tracks':len(d.data['tracks']),'validation':report,'backup':'Projeto novo; originais preservados.'}
    except Exception:
        # Only the exact new directory created by this call is removed on failure.
        shutil.rmtree(folder);raise
