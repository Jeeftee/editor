import hashlib
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def thumbnail(path, catalog):
    if path not in {x['path'] for x in catalog}:
        raise ValueError('Material fora do catálogo.')
    source=Path(path);stat=source.stat()
    key=hashlib.sha256((str(source.resolve())+str(stat.st_size)+str(stat.st_mtime_ns)).encode()).hexdigest()
    destination=ROOT/'data/thumbnails'/(key+'.jpg')
    if not destination.exists():
        destination.parent.mkdir(parents=True,exist_ok=True)
        image=source.suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.webp')
        cmd=['ffmpeg','-v','error','-y']+([] if image else ['-ss','0.1'])+['-i',str(source),'-frames:v','1','-vf','scale=160:-2','-q:v','5',str(destination)]
        subprocess.run(cmd,capture_output=True,check=True,timeout=25)
    return destination.read_bytes()
