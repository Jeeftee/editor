@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
 echo Instale Python 3.11 ou superior com Add Python to PATH e tente novamente.
 pause
 exit /b 1
)
python preparar_local.py
if errorlevel 1 (
 echo A preparacao nao foi concluida. Leia a mensagem acima.
 pause
 exit /b 1
)
pause
