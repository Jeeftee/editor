"""Shared plan rules, media analysis and optional expert-only transcription."""
import array, json, math, re, subprocess, threading, uuid, statistics, hashlib, copy
from pathlib import Path
from catalog import probe, IMAGES

ROOT=Path(__file__).resolve().parents[1]
# Optional pinned local analyzer avoids OpenCV 5 removing Haar cascades.
import sys
if sys.platform=='win32' and (ROOT/'runtime/analysis/cv2').is_dir():sys.path.insert(0,str(ROOT/'runtime/analysis'))
JOBS={}

def library():
    return json.loads((ROOT/'reference/transitions.json').read_text(encoding='utf-8'))

def finite(value, default=0):
    v=float(default if value is None else value)
    if not math.isfinite(v): raise ValueError('Número inválido na timeline.')
    return v

def validate(plan, catalog):
    from visual063 import normalized
    from captions063 import normalized as caption_style
    caption_style(plan)
    indexed={str(Path(v['path']).resolve()).casefold():v for v in catalog}
    def get(c, purpose):
        v=indexed.get(str(Path(c.get('path','')).resolve()).casefold())
        if not v or v.get('error') or v.get('category')!=purpose:
            raise ValueError('Arquivo fora da categoria '+purpose+': '+str(c.get('path')))
        start=finite(c.get('start'));dur=finite(c.get('duration'));src=finite(c.get('source_start'))
        if start<0 or dur<.04 or src<0:raise ValueError('Tempo inválido.')
        if Path(c['path']).suffix.lower() not in IMAGES and src+dur>finite(v['duration'])+.002:
            raise ValueError('Corte ultrapassa a duração da mídia: '+v['name'])
        return v
    bases=sorted(plan.get('bases',[]),key=lambda c:finite(c.get('start')))
    if not bases:raise ValueError('Selecione os vídeos do especialista.')
    cursor=0; current=None;source_cursor=0;seen=set();previous_media=None
    for b in bases:
        normalized(b);v=get(b,'especialista');key=str(Path(b['path']).resolve()).casefold()
        if key!=current:
            if current is not None and abs(source_cursor-finite(previous_media['duration']))>.002:raise ValueError('A narração deve preservar cada base inteira; faltam trechos.')
            if key in seen:raise ValueError('Bases fora da ordem contínua.')
            seen.add(key);current=key;source_cursor=0;previous_media=v
            if not probe(b['path']).get('has_audio'):raise ValueError('Base sem áudio: '+v['name'])
        if abs(finite(b['start'])-cursor)>.002 or abs(finite(b.get('source_start'))-source_cursor)>.002:
            raise ValueError('Os trechos devem preservar toda a narração, contínua e em ordem.')
        source_cursor+=finite(b['duration']);cursor+=finite(b['duration'])
    if abs(source_cursor-finite(previous_media['duration']))>.002:raise ValueError('A narração deve preservar cada base inteira; faltam trechos.')
    from effects064 import validate_effects
    validate_effects(plan.get('effects',[]),cursor)
    clips=sorted(plan.get('clips',[]),key=lambda c:finite(c.get('start')))
    if len(clips)>3000:raise ValueError('Limite de 3000 inserções.')
    previous={}
    for c in clips:
        normalized(c)
        layer=int(c.get('layer',0))
        get(c,'insercoes')
        if finite(c['start'])<previous.get(layer,0)-.002 or finite(c['start'])+finite(c['duration'])>cursor+.002:
            raise ValueError('B-roll sobreposto na mesma camada ou fora da narração.')
        previous[layer]=finite(c['start'])+finite(c['duration'])
    from captions063 import effective
    for cap in plan.get('captions',[]):
        effective(cap,caption_style(plan))
        if not isinstance(cap.get('text'),str) or not cap['text'].strip():raise ValueError('Legenda sem texto.')
        if finite(cap.get('start'))<0 or finite(cap.get('end'))<=finite(cap.get('start')) or finite(cap.get('end'))>cursor+.002:
            raise ValueError('Legenda fora da narração.')
    for edge in plan.get('transitions',[]):
        layer=finite(edge.get('layer'),0)
        if layer!=int(layer) or not 0<=layer<=3:raise ValueError('Camada de transição inválida.')
        if edge.get('preview_kind','none') not in ('none','fade','native'):raise ValueError('Transição inválida.')
        if finite(edge.get('time'))<0 or finite(edge.get('time'))>cursor or not .04<=finite(edge.get('duration'),.35)<=1.5:
            raise ValueError('Transição fora da timeline ou com duração inválida.')
    for k in ('voice','music','insertVolume','sfxVolume'):
        if not 0<=finite(plan.get(k),1 if k=='voice' else .3)<=2:raise ValueError('Volume inválido.')
    from studio068 import validate_additions
    validate_additions(plan,cursor)
    return cursor

def pcm(path):
    raw=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','4000','-f','s16le','pipe:1'],capture_output=True,check=True,timeout=180).stdout
    samples=array.array('h');samples.frombytes(raw[:len(raw)//2*2]);return samples

def audio_analysis(path, split=False):
    a=pcm(path);hop=200
    energies=[math.sqrt(sum(x*x for x in a[i:i+hop])/max(1,len(a[i:i+hop]))) for i in range(0,len(a),hop)]
    if not energies:return {'audible_start_s':0,'peak_s':0,'regions':[]}
    threshold=max(80,max(energies)*.05)
    onset=next((i for i,e in enumerate(energies) if e>threshold),0)
    result={'audible_start_s':round(onset*.05,3),'peak_s':round(max(range(len(energies)),key=energies.__getitem__)*.05,3)}
    regions=[];begin=None;silent=0
    for i,e in enumerate(energies+[0]*10):
        if e>threshold:
            if begin is None:begin=max(0,i-2)
            silent=0
        elif begin is not None:
            silent+=1
            if silent>=8:
                end=min(len(energies),i-5)
                if end>begin:
                    peak=max(range(begin,end),key=energies.__getitem__)
                    if (end-begin)*.05<=12:regions.append({'source_start':round(begin*.05,3),'duration':round((end-begin)*.05,3),'peak_s':round((peak-begin)*.05,3)})
                begin=None;silent=0
    if not split:regions=[]
    result['regions']=regions;return result

def split_detection(path):
    meta=probe(path)
    if not meta.get('width') or meta['height']<=meta['width']:
        return {'detected':False,'reason':'Arquivo não vertical.'}
    w,h=90,160;cuts=[]
    for frac in (.15,.35,.55,.75,.9):
        r=subprocess.run(['ffmpeg','-v','error','-ss',str(meta['duration']*frac),'-i',str(path),'-frames:v','1','-vf',f'scale={w}:{h}','-pix_fmt','gray','-f','rawvideo','pipe:1'],capture_output=True,check=True,timeout=20)
        if len(r.stdout)!=w*h:continue
        bright=[sum(r.stdout[y*w:(y+1)*w])/w>12 for y in range(h)]
        active=[y for y,b in enumerate(bright) if b]
        if active:cuts.append((min(active)/h,(max(active)+1)/h))
    if len(cuts)<3:return {'detected':False,'reason':'Amostras insuficientes.'}
    top=statistics.median(x[0] for x in cuts);bottom=statistics.median(x[1] for x in cuts)
    stable=max(abs(a-top)+abs(b-bottom) for a,b in cuts)<.10
    detected=stable and top>.17 and bottom<.83 and .12<bottom-top<.6
    return {'detected':detected,'crop':{'top':round(top,4),'bottom':round(bottom,4)},'samples':len(cuts),'reason':'Bordas pretas consistentes em 5 amostras.' if detected else 'Não confirmou conteúdo horizontal central; revise manualmente.'}

def caption_groups(segments, words_per_caption=3):
    out=[]
    for s in segments:
        words=s.get('words') or []
        if not words:
            tokens=s.get('text','').split();a=finite(s['start']);b=finite(s['end'])
            words=[{'word':w,'start':a+(b-a)*i/max(1,len(tokens)),'end':a+(b-a)*(i+1)/max(1,len(tokens))} for i,w in enumerate(tokens)]
        for i in range(0,len(words),words_per_caption):
            chunk=words[i:i+words_per_caption]
            if chunk and chunk[-1]['end']>chunk[0]['start']:
                out.append({'start':round(chunk[0]['start'],4),'end':round(chunk[-1]['end'],4),'text':' '.join(w['word'].strip() for w in chunk),'timing':'word' if s.get('words') else 'interpolated','words':copy.deepcopy(chunk)})
    return out

def sfx_events(plan, catalog):
    if plan.get('sfxMode','on')=='off':return []
    if plan.get('sfxManual'):return plan.get('sfxEvents',[])
    available=[]
    for item in catalog:
        regions=item.get('regions') or ([{'source_start':0,'duration':item['duration'],'peak_s':item.get('peak_s',0)}] if item['duration']<=12 else [])
        available.extend({**r,'path':item['path'],'name':item['name']} for r in regions if r['duration']>=.1)
    if not available:return []
    events=[];end=0
    for i,edge in enumerate(sorted(plan.get('transitions',[]),key=lambda x:x['time'])):
        if not edge.get('resource_id'):continue
        sound=available[i%len(available)];start=edge['time']-sound['peak_s'];src=sound.get('source_start',0);dur=sound['duration']
        if start<0:src-=start;dur+=start;start=0
        if start<end or dur<.1:continue
        events.append({**sound,'start':round(start,6),'source_start':src,'duration':dur,'gain':plan.get('sfxVolume',.3),'edge':edge['time']})
        end=start+dur
    # Manual events are the source of truth once the user edits them.
    return plan.get('sfxEvents') if plan.get('sfxManual') else events

def transcribe_job(plan, catalog):
    validate(plan,catalog)
    job=uuid.uuid4().hex;JOBS[job]={'status':'running','progress':'Preparando áudio do especialista'}
    def run():
        try:
            try:from faster_whisper import WhisperModel
            except ImportError:raise ValueError('Instale o módulo opcional executando INSTALAR_LEGENDAS.bat. Alternativa: importe SRT do especialista.')
            model_name=plan.get('whisperModel','small')
            if model_name not in ('tiny','base','small','medium'):raise ValueError('Modelo inválido.')
            model=None;cache=ROOT/'data/transcript_cache';cache.mkdir(parents=True,exist_ok=True)
            words=[]
            logical=[]
            for segment in plan['bases']:
                if logical and logical[-1]['path']==segment['path']:logical[-1]['duration']+=segment['duration']
                else:logical.append(dict(segment))
            for base in logical:
                path=Path(base['path']);stat=path.stat();key=hashlib.sha256(json.dumps([str(path.resolve()),stat.st_size,stat.st_mtime_ns,model_name,'word-vad-v1']).encode()).hexdigest()
                cached=cache/(key+'.json')
                if cached.exists():
                    JOBS[job]['progress']='Reutilizando transcrição de '+path.name;local=json.loads(cached.read_text(encoding='utf-8'))
                else:
                    if model is None:
                        JOBS[job]['progress']='Carregando modelo local; primeiro uso pode baixar os pesos.'
                        local_model=ROOT/'models'/model_name
                        model=WhisperModel(str(local_model) if (local_model/'model.bin').is_file() else model_name,device='cpu',compute_type='int8',download_root=str(ROOT/'models'))
                    JOBS[job]['progress']='Transcrevendo '+path.name
                    segs,_=model.transcribe(base['path'],word_timestamps=True,vad_filter=True)
                    local=[]
                    for s in segs:
                        limit=finite(base['duration'])
                        a=max(0,s.start);b=min(limit,s.end)
                        if b<=a:continue
                        ws=[{'word':w.word,'start':max(a,w.start),'end':min(b,w.end)} for w in s.words or [] if min(b,w.end)>max(a,w.start)]
                        local.append({'start':a,'end':b,'text':s.text,'words':ws})
                    temp=cached.with_suffix('.'+uuid.uuid4().hex+'.tmp');temp.write_text(json.dumps(local,ensure_ascii=False),encoding='utf-8');temp.replace(cached)
                for source in local:
                    segment=copy.deepcopy(source);offset=base['start'];limit=finite(base['duration']);segment['start']=max(0,segment['start']);segment['end']=min(limit,segment['end'])
                    if segment['end']<=segment['start']:continue
                    segment['words']=[{**w,'start':max(segment['start'],w['start']),'end':min(segment['end'],w['end'])} for w in segment.get('words',[]) if min(segment['end'],w['end'])>max(segment['start'],w['start'])]
                    segment['start']+=offset;segment['end']+=offset
                    for word in segment['words']:word['start']+=offset;word['end']+=offset
                    words.append(segment)
            JOBS[job]={'status':'done','captions':caption_groups(words),'source':'specialist_only'}
        except Exception as exc:JOBS[job]={'status':'error','error':str(exc)}
    threading.Thread(target=run,daemon=True).start();return {'job':job}

def preliminary_faces(base):
    # This is deliberately NOT a lip-sync classifier.
    try:import cv2
    except ImportError:raise ValueError('Instale OpenCV com INSTALAR_ANALISE.bat.')
    if not hasattr(cv2,'CascadeClassifier'):
        raise ValueError('Triagem indisponível: instale opencv-python-headless versão 4 no Python usado pelo editor. Nenhuma análise facial foi realizada.')
    detector=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    capture=cv2.VideoCapture(base['path']);duration=base['duration'];markers=[]
    try:
        for t in range(0,math.ceil(duration),2):
            capture.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,frame=capture.read()
            if not ok:continue
            frame=cv2.resize(frame,(320,max(1,round(frame.shape[0]*320/frame.shape[1]))))
            faces=detector.detectMultiScale(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),1.1,5)
            if len(faces)!=1:markers.append({'start':base['start']+t,'end':min(base['start']+duration,base['start']+t+2),'reason':'Rosto ausente ou múltiplo na amostra','confidence':'preliminary','cover_suggestion':True})
    finally:capture.release()
    return {'markers':markers,'warning':'Triagem de presença facial apenas. Não mede sincronização labial nem distorção de boca. Confirme visualmente; nenhuma inserção é aplicada automaticamente.'}
