"""Portable caption styles; no dependency on proprietary online effect engines."""
import re, copy, math
from pathlib import Path
FONTS={'arial':('Arial','arialbd.ttf'),'segoe':('Segoe UI','segoeuib.ttf'),'impact':('Impact','impact.ttf'),'arial_regular':('Arial Regular','arial.ttf')}
DEFAULT={'preset':'classic','font':'arial','size':84,'color':'#ffffff','highlight':'#ffd84a','stroke':6,'background':False,'uppercase':False,'x':.5,'y':.8,'animation':'pulse','karaoke':False}
PRESETS=[{'id':'classic','name':'Clássica','style':DEFAULT},
 {'id':'vsl','name':'Destaque VSL','style':{**DEFAULT,'preset':'vsl','font':'impact','size':88,'uppercase':True,'color':'#ffd84a','animation':'pop'}},
 {'id':'karaoke','name':'Palavra ativa','style':{**DEFAULT,'preset':'karaoke','karaoke':True,'animation':'none'}},
 {'id':'box','name':'Caixa de legenda','style':{**DEFAULT,'preset':'box','background':True,'stroke':0,'size':72,'animation':'pop'}},
 {'id':'minimal','name':'Minimalista','style':{**DEFAULT,'preset':'minimal','font':'segoe','size':66,'stroke':2,'animation':'none'}}]

def font_path(key):
    if key not in FONTS: raise ValueError('Fonte de legenda inválida.')
    path=Path('C:/Windows/Fonts')/FONTS[key][1]
    try:return path if path.is_file() else None
    except OSError:return None

def catalog():
    return {'presets':PRESETS,'fonts':[{'id':key,'name':name,'available':font_path(key) is not None} for key,(name,_) in FONTS.items()], 'scope':'Presets inspirados em editores como o CapCut; fontes locais disponíveis, sem baixar recursos proprietários.'}

def normalized(plan):
    raw=plan.get('captionStyle') or {}
    if not isinstance(raw,dict):raise ValueError('Estilo de legenda inválido.')
    s={**DEFAULT,**raw}
    if s['font'] not in FONTS:raise ValueError('Fonte de legenda inválida.')
    for key,lo,hi in [('size',32,120),('stroke',0,12),('x',0,1),('y',0,1)]:
        try:value=float(s[key])
        except (ValueError,TypeError):raise ValueError('Ajuste de legenda inválido: '+key)
        if not math.isfinite(value) or not lo<=value<=hi:raise ValueError('Ajuste de legenda fora do limite: '+key)
        s[key]=value
    for key in ('color','highlight'):
        if not isinstance(s[key],str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',s[key]):raise ValueError('Cor de legenda inválida.')
    for key in ('background','uppercase','karaoke'):
        if not isinstance(s[key],bool):raise ValueError('Opção de legenda inválida: '+key)
    if s['animation'] not in ('none','pop','pulse','zoom','typewriter'):raise ValueError('Animação de legenda inválida.')
    return s

def word_timings(c):
    tokens=c['text'].split();words=c.get('words') or [];usable=len(words)==len(tokens)
    if usable:
        try:
            starts=[float(w['start']) for w in words]
            ends=[float(w['end']) for w in words]
            usable=all(math.isfinite(a) and math.isfinite(b) and c['start']-.001<=a<=b<=c['end']+.001 for a,b in zip(starts,ends)) and starts==sorted(starts)
        except (KeyError,TypeError,ValueError):usable=False
    if not usable:
        span=c['end']-c['start'];starts=[c['start']+span*i/max(1,len(tokens)) for i in range(len(tokens))];ends=[c['start']+span*(i+1)/max(1,len(tokens)) for i in range(len(tokens))]
    return [{'word':token,'start':a,'end':b} for token,a,b in zip(tokens,starts,ends)],not usable or c.get('timing')=='interpolated'

def states(c,style):
    words,estimated=word_timings(c)
    if not (style['karaoke'] or style['animation']=='typewriter') or not words:return [{**c,'active_word':-1,'animation_origin':c['start'],'estimated':estimated}]
    # Include silence gaps explicitly, never stretch a highlighted word into a pause.
    points=sorted({c['start'],c['end']}|{t for w in words for t in (w['start'],w['end'])})
    out=[]
    for a,b in zip(points,points[1:]):
        if b-a<.0001:continue
        middle=(a+b)/2;active=next((i for i,w in enumerate(words) if w['start']<=middle<w['end']),-1)
        revealed=sum(w['start']<=middle for w in words)
        text=' '.join(w['word'] for w in words[:revealed]) if style['animation']=='typewriter' else c['text']
        if text:out.append({**c,'start':a,'end':b,'text':text,'active_word':active,'animation_origin':c['start'],'estimated':estimated})
    return out

def content(c,style):
    text=c['text'].upper() if style['uppercase'] else c['text'];tokens=text.split();ranges=[];cursor=0
    for i,word in enumerate(tokens):
        start=text.find(word,cursor);cursor=start+len(word)
        color=style['highlight'] if style['karaoke'] and i==c.get('active_word',-1) else style['color']
        rgb=[int(color[k:k+2],16)/255 for k in (1,3,5)]
        item={'fill':{'content':{'render_type':'solid','solid':{'color':rgb}}},'font':{'path':font_path(style['font']).as_posix() if font_path(style['font']) else '', 'id':''},'size':style['size']/8.4,'range':[len(text[:start].encode('utf-16-le'))//2,len(word.encode('utf-16-le'))//2]}
        if style['stroke']:item['strokes']=[{'content':{'render_type':'solid','solid':{'color':[0,0,0]}},'width':style['stroke']/style['size'],'mode':0}]
        ranges.append(item)
    return {'text':text,'styles':ranges}

def reference_styles(folder):
    """Read only user-selected reference drafts; map unavailable fonts explicitly."""
    import json
    root=Path(folder).expanduser().resolve()
    if not folder or not root.is_dir():raise ValueError('Escolha a pasta de exemplos do projeto.')
    out=[];seen=set()
    files=sorted(root.rglob('draft_content.json'))+sorted(root.rglob('draft_content.json.bak'))
    for file in files[:50]:
        if file.stat().st_size>30_000_000:continue
        try: data=json.loads(file.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):continue
        for m in data.get('materials',{}).get('texts',[]):
            name=m.get('style_name') or m.get('preset_name') or 'Referência '+str(len(out)+1)
            color=m.get('text_color') or '#ffffff'
            if not re.fullmatch(r'#[0-9a-fA-F]{6}',color):color='#ffffff'
            font_name=m.get('font_name') or m.get('font_title') or 'Fonte do projeto';key=next((k for k,(n,_) in FONTS.items() if n.casefold()==font_name.casefold()),'arial')
            fingerprint=(font_name,color,m.get('font_size'),m.get('border_width'),m.get('background_color'))
            if fingerprint in seen:continue
            seen.add(fingerprint);style={**DEFAULT,'preset':'reference','font':key,'color':color,'size':max(32,min(120,float(m.get('font_size') or 10)*8.4)),'stroke':max(0,min(12,float(m.get('border_width') or 0)*84)),'background':bool(m.get('background_color'))}
            out.append({'id':'reference_'+str(len(out)), 'name':name,'style':style,'original_font':font_name,'font_substituted':font_name.casefold()!=FONTS[key][0].casefold(),'source':file.name})
            if len(out)>=20:return {'presets':out,'scope':'Cores, tamanhos e bordas lidos dos exemplos; animações e fontes proprietárias não recuperadas.'}
    return {'presets':out,'scope':'Cores, tamanhos e bordas lidos dos exemplos; animações e fontes proprietárias não recuperadas.'}


def effective(c, global_style):
    raw=c.get('style') or {}
    if not isinstance(raw,dict):raise ValueError('Ajustes individuais de legenda inválidos.')
    return normalized({'captionStyle':{**global_style,**raw}})
