import copy, json, os, subprocess, sys, unittest, uuid, shutil
from pathlib import Path
from PIL import Image
APP=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP/'backend'))
os.environ['PATH']=str(APP/'runtime/ffmpeg')+os.pathsep+os.environ['PATH']
from visual063 import normalized, mask_image, bake
from editor06 import validate
from export06 import export_plan
from catalog import scan

class Visual(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=APP/'tests'/('visual063_'+uuid.uuid4().hex);cls.root.mkdir()
        for folder in ('especialista','insercoes','export'): (cls.root/folder).mkdir()
        cls.base=cls.root/'especialista/base1.mp4';cls.image=cls.root/'insercoes/orange.png'
        subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=blue:s=180x320:r=30:d=2','-f','lavfi','-i','sine=frequency=440:duration=2','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(cls.base)],check=True)
        Image.new('RGB',(180,320),'orange').save(cls.image)
        cls.catalog=scan(cls.root);cls.plan={'bases':[{'path':str(cls.base),'start':0,'duration':2,'source_start':0}], 'clips':[{'path':str(cls.image),'start':.2,'duration':1.2,'source_start':0}], 'transitions':[], 'project':str(cls.root/'export')}
    @classmethod
    def tearDownClass(cls):
        assert cls.root.resolve().parent==(APP/'tests').resolve()
        shutil.rmtree(cls.root)
    def test_layer_overlap_guard(self):
        p=copy.deepcopy(self.plan);p['clips'].append({**p['clips'][0],'layer':1});self.assertEqual(validate(p,self.catalog),2)
        p['clips'][1]['layer']=0
        with self.assertRaisesRegex(ValueError,'mesma camada'):validate(p,self.catalog)
    def test_invalid_visual_cannot_be_saved_or_exported(self):
        for visual in ({'scale':float('nan')},{'mask':{'type':'unrecognized'}},{'mask':{'feather':2}},{'x':3}):
            p=copy.deepcopy(self.plan);p['clips'][0]['visual']=visual
            with self.assertRaises(ValueError):validate(p,self.catalog)
    def test_soft_mask_has_partial_alpha_and_inversion(self):
        v=normalized({'visual':{'mask':{'type':'rectangle','width':.6,'height':.6,'roundness':.6,'feather':.4}}})
        image=mask_image(v,(180,320));self.assertEqual(image.getpixel((0,0)),0);self.assertGreater(image.getpixel((90,160)),240)
        self.assertTrue(any(0<p<255 for p in image.getdata()))
        v['mask']['invert']=True;inverted=mask_image(v,(180,320));self.assertEqual(inverted.getpixel((0,0)),255);self.assertLess(inverted.getpixel((90,160)),15)
    def test_baked_mask_transform_preserves_alpha(self):
        e={'path':str(self.image),'duration':.3,'visual':{'x':.12,'scale':.8,'mask':{'type':'circle','width':.8,'height':.6,'feather':.25}}}
        path=bake(e,{'width':180,'height':320},self.root,size=(180,320))
        dest=self.root/'frame.png';subprocess.run(['ffmpeg','-v','error','-y','-i',str(path),'-frames:v','1','-pix_fmt','rgba',str(dest)],check=True)
        img=Image.open(dest).convert('RGBA');a=img.getchannel('A');self.assertEqual(a.getpixel((0,0)),0);self.assertGreater(a.getpixel((112,160)),240);self.assertTrue(any(5<p<245 for p in a.getdata()))
        values=list(a.getdata());mass=sum(values);center=sum((i%180)*v for i,v in enumerate(values))/mass;self.assertGreater(center,105)
    def test_original_png_transparency_survives_effect(self):
        path=self.root/'transparent.png';im=Image.new('RGBA',(180,320),(0,0,0,0));im.paste((255,0,0,255),(60,100,120,220));im.save(path)
        result=bake({'path':str(path),'duration':.2,'visual':{'brightness':1.2}}, {'width':180,'height':320},self.root,size=(180,320));out=self.root/'alpha.png'
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(result),'-frames:v','1','-pix_fmt','rgba',str(out)],check=True)
        alpha=Image.open(out).convert('RGBA').getchannel('A');self.assertEqual(alpha.getpixel((20,20)),0);self.assertGreater(alpha.getpixel((90,160)),250)
    def test_optional_dissolve_renders_alpha_not_a_default_transition(self):
        e={'path':str(self.image),'duration':.6}
        result=bake(e,{'width':180,'height':320},self.root,fade_in=.2,fade_out=.2,size=(180,320))
        values=[]
        for i,t in enumerate((0,.3,.566)):
            out=self.root/('fade'+str(i)+'.png')
            subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(result),'-frames:v','1','-pix_fmt','rgba',str(out)],check=True)
            values.append(Image.open(out).convert('RGBA').getpixel((90,160))[3])
        self.assertLess(values[0],5);self.assertGreater(values[1],250);self.assertLess(values[2],90)
    def test_export_layers_soft_mask_and_full_voice(self):
        p=copy.deepcopy(self.plan);p['clips'][0]['visual']={'mask':{'type':'rectangle','width':.7,'height':.7,'roundness':.5,'feather':.2}}
        p['clips'].append({**copy.deepcopy(p['clips'][0]),'layer':1,'visual':{'scale':.5,'x':.2}})
        result=export_plan(p,self.catalog,[],[]);folder=Path(result['project']);data=json.loads((folder/'draft_content.json').read_text())
        voice=next(t for t in data['tracks'] if t['name']=='VSL06 VOZ INTEGRAL');self.assertEqual(sum(s['target_timerange']['duration'] for s in voice['segments']),2000000)
        layers=[t for t in data['tracks'] if t['name'].startswith('VSL06 B-ROLL')];self.assertEqual(len(layers),2)
        mats={m['id']:m for m in data['materials']['videos']}
        for layer in layers:
            rendered=[s for s in layer['segments'] if s['clip']['alpha']>0];self.assertEqual(len(rendered),1);s=rendered[0];self.assertEqual(s['source_timerange']['start'],0);self.assertTrue(mats[s['material_id']]['path'].endswith('.mov'))
        saved=json.loads((folder/'vsl06_plan.json').read_text());self.assertEqual(saved['clips'][0]['visual'],p['clips'][0]['visual']);self.assertTrue(self.image.exists())

if __name__=='__main__':unittest.main(verbosity=2)
