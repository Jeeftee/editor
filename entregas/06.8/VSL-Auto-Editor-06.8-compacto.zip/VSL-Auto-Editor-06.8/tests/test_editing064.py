import sys,unittest,copy,json,uuid,shutil,io,subprocess
from pathlib import Path
from unittest.mock import patch
from PIL import Image
APP=Path(__file__).resolve().parents[1];sys.path.insert(0,str(APP/'backend'))
from editor06 import validate
from captions063 import effective,normalized
from effects064 import generate,frame,normalize
from export06 import export_plan
from catalog import scan
from render064 import start,append,finish,SESSIONS,mix_audio
import numpy as np

class Editing064(unittest.TestCase):
 def setUp(self):
  self.root=APP/'tests'/('v064_'+uuid.uuid4().hex);self.root.mkdir();(self.root/'especialista').mkdir();self.media=(self.root/'especialista/base1.mp4').resolve();subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=blue:s=90x160:r=30:d=8','-f','lavfi','-i','sine=frequency=440:duration=8','-c:v','libx264','-c:a','aac','-shortest',str(self.media)],check=True);self.catalog=scan(self.media.parent);self.base={'path':str(self.media),'start':0,'duration':8,'source_start':0};self.plan={'bases':[self.base],'clips':[],'captions':[],'transitions':[],'project':str(self.root)}
 def tearDown(self):shutil.rmtree(self.root)
 def test_split_complete_voice_and_gaps_rejected(self):
  self.plan['bases']=[{**self.base,'duration':3},{**self.base,'start':3,'duration':5,'source_start':3,'visual':{'x':.1}}];self.assertEqual(validate(self.plan,self.catalog),8)
  bad=copy.deepcopy(self.plan);bad['bases'][1]['source_start']=3.1
  with self.assertRaises(ValueError):validate(bad,self.catalog)
  bad=copy.deepcopy(self.plan);bad['bases'][1]['duration']=4
  with self.assertRaises(ValueError):validate(bad,self.catalog)
 def test_caption_override_and_native_position(self):
  self.plan['captions']=[{'start':0,'end':1,'text':'Primeira','style':{'x':.2,'y':.3,'font':'impact'}},{'start':1,'end':2,'text':'Segunda'}];global_style=normalized({});self.assertEqual(effective(self.plan['captions'][0],global_style)['x'],.2);self.assertEqual(effective(self.plan['captions'][1],global_style)['x'],.5)
  result=export_plan(self.plan,self.catalog,[],[]);draft=json.loads((Path(result['project'])/'draft_content.json').read_text(encoding='utf8'));text=next(t for t in draft['tracks'] if t['type']=='text')['segments'];self.assertAlmostEqual(text[0]['clip']['transform']['x'],-.6);self.assertAlmostEqual(text[0]['clip']['transform']['y'],.4);self.assertEqual(text[1]['clip']['transform']['x'],0)
 def test_capcut_split_sources_and_voice(self):
  self.plan['bases']=[{**self.base,'duration':3},{**self.base,'start':3,'duration':5,'source_start':3}];result=export_plan(self.plan,self.catalog,[],[]);d=json.loads((Path(result['project'])/'draft_content.json').read_text(encoding='utf8'));voice=next(t for t in d['tracks'] if t['name']=='VSL06 VOZ INTEGRAL')['segments'];self.assertEqual(sum(x['target_timerange']['duration'] for x in voice),8000000);self.assertEqual(voice[1]['source_timerange']['start'],3000000)
 def test_effect_generated_without_external_call(self):
  e=generate({'prompt':'seta vermelha pulsando','mode':'local','start':1,'duration':2})['effect'];self.assertEqual(e['kind'],'arrow');self.assertEqual(e['color'],'#ff4444');a=frame(e,1.1);self.assertEqual(a.getpixel((0,0))[3],0);self.assertGreater(a.getpixel((270,480))[3],0)
 def test_ai_adapter_validates_response_and_does_not_send_media(self):
  reply={'output':[{'content':[{'type':'output_text','text':json.dumps({'kind':'ring','color':'#ffff00','text':'','animation':'pop','size':.3,'rotation':0})}]}]};stream=io.BytesIO(json.dumps(reply).encode())
  with patch('effects064.urlopen',return_value=stream) as send:
   result=generate({'mode':'openai','apiKey':'test-only','model':'test-model','prompt':'círculo sobre o produto'})
   self.assertEqual(result['effect']['kind'],'ring');body=json.loads(send.call_args.args[0].data);self.assertFalse(body['store']);self.assertEqual(body['text']['format']['type'],'json_schema');self.assertNotIn('image',json.dumps(body))
  with self.assertRaises(ValueError):normalize({'kind':'execute_code'})
 def test_incomplete_render_cleans_owned_temp(self):
  self.plan['mp4Folder']=str(self.root);r=start(self.plan,self.catalog,[],[]);token=r['session'];temp=SESSIONS[token]['temp']
  with self.assertRaises(ValueError):finish(token)
  self.assertFalse(temp.exists());self.assertNotIn(token,SESSIONS)
 def test_audio_mix_optional_music_sfx_and_layer_audio(self):
  music=self.root/'music.wav';sound=self.root/'effect.wav'
  for file,freq in [(music,880),(sound,1760)]:subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',f'sine=frequency={freq}:duration=1','-c:a','pcm_s16le',str(file)],check=True)
  p={**self.plan,'voice':.3,'musicPath':str(music),'music':.2,'musicCrossfade':.2,'insertVolume':.2,'clips':[{'path':str(self.media),'start':4,'duration':1,'source_start':0}], 'sfxManual':True,'sfxEvents':[{'path':str(sound),'start':2,'duration':1,'source_start':0,'gain':.5}]}
  raw,peak=mix_audio({'plan':p,'duration':8,'temp':self.root,'music':[{'path':str(music),'duration':1}],'sfx':[{'path':str(sound),'duration':1}]},lambda _:None)
  audio=np.fromfile(raw,dtype='float32').reshape(-1,2)[:,0];self.assertEqual(len(audio),8*48000)
  def power(t,freq):
   wave=audio[round(t*48000):round((t+.2)*48000)];spectrum=np.abs(np.fft.rfft(wave));return spectrum[round(freq*.2)]
  self.assertGreater(power(.3,440),10);self.assertGreater(power(.3,880),10);self.assertGreater(power(2.3,1760),power(.3,1760)*5+10);self.assertGreater(power(4.3,440),power(.3,440)*1.3);self.assertLessEqual(float(np.max(np.abs(audio))),.991)
 def test_invalid_individual_style_rejected(self):
  self.plan['captions']=[{'start':1,'end':2,'text':'Legenda','style':{'x':float('nan')}}]
  with self.assertRaises(ValueError):validate(self.plan,self.catalog)

if __name__=='__main__':unittest.main(verbosity=2)
