@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe python -m venv .venv
if errorlevel 1 goto erro
.venv\Scripts\python.exe -m pip install "opencv-python-headless>=4.10,<5"
if errorlevel 1 goto erro
echo Analise facial preliminar instalada. Reinicie pelo INICIAR.bat.
pause
exit /b 0
:erro
echo Falha na instalacao. Confira a mensagem acima.
pause
exit /b 1
