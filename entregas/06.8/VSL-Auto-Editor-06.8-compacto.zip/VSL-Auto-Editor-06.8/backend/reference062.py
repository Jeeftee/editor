from pathlib import Path

def draft_files(root, limit=200):
    """Prefer the working JSON when a backup of the same draft also exists."""
    root=Path(root)
    found=[]
    for path in sorted(root.rglob('draft_content.json*')):
        if path.name not in ('draft_content.json','draft_content.json.bak'):continue
        if 'subdraft' in str(path.relative_to(root)).lower():continue
        if path.name.endswith('.bak') and path.with_suffix('').is_file():continue
        found.append(path)
        if len(found)>=limit:break
    return found
