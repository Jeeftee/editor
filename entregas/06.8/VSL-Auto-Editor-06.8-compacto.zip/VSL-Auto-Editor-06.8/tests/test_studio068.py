import sys,unittest,tempfile,math,copy,wave
from pathlib import Path
APP=Path(__file__).resolve().parents[1];sys.path.insert(0,str(APP/'backend'))
from studio068 import motion_values,validate_music,validate_additions,synthesize,KINDS,MOTIONS,coverage
from effects064 import normalize,frame
from motion068 import keyframes
from render064 import start,cancel

class Studio068(unittest.TestCase):
 def test_all_motion_presets_and_graphics_render(self):
  for kind in KINDS:
   for animation in MOTIONS:
    e=normalize({'kind':kind,'animation':animation,'start':0,'duration':2,'text':'Teste','value':250})
    image=frame(e,.7);self.assertEqual(image.size,(540,960));self.assertIsNotNone(image.getbbox())
 def test_motion_cut_keeps_original_phase(self):
  for kind in MOTIONS:
   left={'motion':kind,'duration':3,'motion_duration':3};right={**left,'duration':2,'motion_offset':1}
   self.assertEqual(motion_values(left,1.2),motion_values(right,.2))
  e={'kind':'particles','start':0,'duration':3,'animation':'rotate','motion_duration':3}
  self.assertEqual(frame(e,1.2).tobytes(),frame({**e,'start':1,'duration':2,'motion_offset':1},1.2).tobytes())
 def test_invalid_graphics_rejected(self):
  for value in [float('nan'),float('inf'),-1]:
   with self.assertRaises(ValueError):normalize({'value':value})
  with self.assertRaises(ValueError):normalize({'animation':'execute'})
 def test_music_edits_may_overlap_across_tracks_not_same_track(self):
  music=[{'path':'a.wav','duration':5}];c={'path':'a.wav','start':0,'duration':3,'source_start':0,'gain':.4,'lane':0}
  p={'musicManual':True,'musicClips':[c,{**c,'start':2,'lane':1}]};validate_music(p,music,5)
  with self.assertRaises(ValueError):validate_music({**p,'musicClips':[c,{**c,'start':2}]},music,5)
  with self.assertRaises(ValueError):validate_music({**p,'musicClips':[{**c,'source_start':4}]},music,5)
  with self.assertRaises(ValueError):validate_music({**p,'musicClips':[{**c,'gain':math.nan}]},music,5)
 def test_synthesized_sounds_are_valid_non_silent_local_wav(self):
  paths=[]
  for preset in ['whoosh','impact','chime','riser','click']:
   item=synthesize({'preset':preset,'duration':.35});paths.append(Path(item['path']))
   with wave.open(item['path']) as sound:
    self.assertEqual(sound.getframerate(),48000);self.assertEqual(sound.getnframes(),16800);self.assertNotEqual(set(sound.readframes(16800)),{0})
  for p in paths:p.unlink()
 def test_keyframes_include_duration_and_motion(self):
  for kind in MOTIONS[1:]:
   frames=keyframes({'motion':kind,'duration':2})
   self.assertTrue(frames)
   for prop in frames:
    self.assertEqual(prop['keyframe_list'][0]['time_offset'],0);self.assertEqual(prop['keyframe_list'][-1]['time_offset'],2000000)
 def test_groups_reject_unknown_memberships(self):
  validate_additions({'compounds':[{'id':'g','name':'Grupo'}],'effects':[{'compoundId':'g'}]},3)
  with self.assertRaises(ValueError):validate_additions({'effects':[{'compoundId':'missing'}]},3)
 def test_expert_has_no_automatic_motion(self):
  with self.assertRaises(ValueError):validate_additions({'bases':[{'motion':'zoom'}]},3)

if __name__=='__main__':unittest.main(verbosity=2)
