import sqlite3
from pathlib import Path
DB = Path(__file__).resolve().parents[1] / 'data' / 'catalog.db'

def save(items, merge=False):
    DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB) as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS videos (path TEXT PRIMARY KEY, name TEXT, category TEXT, relative_path TEXT, size_mb REAL, duration REAL, width INTEGER, height INTEGER, error TEXT)')
        if not merge:conn.execute('DELETE FROM videos')
        conn.executemany('INSERT OR REPLACE INTO videos VALUES (:path, :name, :category, :relative_path, :size_mb, :duration, :width, :height, :error)', items)

def load():
    if not DB.exists(): return []
    with sqlite3.connect(DB) as conn:
        conn.row_factory = sqlite3.Row
        return [dict(row) for row in conn.execute('SELECT * FROM videos ORDER BY category, name')]
