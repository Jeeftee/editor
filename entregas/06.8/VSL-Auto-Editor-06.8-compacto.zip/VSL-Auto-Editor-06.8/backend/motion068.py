"""Editable sampled CapCut transform keyframes; native application acceptance remains untested."""
import uuid
from studio068 import motion_values

def keyframes(c):
    duration=c['duration'];keys=[]
    properties={'KFTypeScaleX':'scale','KFTypeScaleY':'scale','KFTypePositionX':'x','KFTypePositionY':'y','KFTypeRotation':'rotation','KFTypeAlpha':'opacity'}
    times=sorted({0,duration,*[min(duration,i*.1) for i in range(min(600,int(duration*10)+1))]})
    values=[motion_values(c,t) for t in times]
    for prop,key in properties.items():
        base=0 if key in ('x','y','rotation') else 1
        if all(abs(v[key]-base)<1e-9 for v in values):continue
        # Static visuals are baked into transparent full-canvas media first.
        multiplier=2 if key=='x' else -2 if key=='y' else 1
        keys.append({'id':uuid.uuid4().hex,'material_id':'','property_type':prop,'keyframe_list':[{'id':uuid.uuid4().hex,'time_offset':round(t*1e6),'values':[v[key]*multiplier],'curveType':'Line','left_control':{'x':0.,'y':0.},'right_control':{'x':0.,'y':0.},'string_value':'','graphID':''} for t,v in zip(times,values)]})
    return keys
