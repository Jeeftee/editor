"""Reaproveita somente runtime/modelos do ZIP original verificado, sem alterar o ZIP."""
import hashlib
import shutil
import sys
import zipfile
from pathlib import Path

EXPECTED = 'a708907c393ad1439810e8832621f36ac08b61b71b189facb3059819f5440810'
ROOT = Path(__file__).resolve().parent

def prepare(source, destination=ROOT):
    source=Path(source);destination=Path(destination).resolve()
    print('Verificando o ZIP original da versão 6.4...',flush=True)
    digest=hashlib.sha256()
    with source.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    if digest.hexdigest()!=EXPECTED:
        raise ValueError('Este não é o ZIP 06.4-estudio usado como base. Selecione VSL-Auto-Editor-06.4-estudio.zip, sem modificações.')
    count=0
    with zipfile.ZipFile(source) as archive:
        for info in archive.infolist():
            parts=Path(info.filename).parts
            if len(parts)<3 or parts[0]!='VSL-Auto-Editor-06.4' or parts[1] not in ('runtime','models') or info.is_dir():continue
            if '__pycache__' in parts or parts[-1]=='.lock':continue
            target=destination.joinpath(*parts[1:])
            if not target.resolve().is_relative_to(destination):raise ValueError('Caminho inválido no ZIP.')
            if target.exists():
                raise ValueError('Já existem arquivos de runtime/modelos nesta pasta. Extraia o pacote compacto em uma pasta nova para preservar seus arquivos.')
    print('Copiando FFmpeg e modelos para a versão 6.8...',flush=True)
    with zipfile.ZipFile(source) as archive:
        for info in archive.infolist():
            parts=Path(info.filename).parts
            if len(parts)<3 or parts[0]!='VSL-Auto-Editor-06.4' or parts[1] not in ('runtime','models') or info.is_dir() or '__pycache__' in parts or parts[-1]=='.lock':continue
            target=destination.joinpath(*parts[1:]);target.parent.mkdir(parents=True,exist_ok=True)
            with archive.open(info) as incoming,target.open('xb') as outgoing:shutil.copyfileobj(incoming,outgoing)
            count+=1
    if not (destination/'runtime/ffmpeg/ffmpeg.exe').is_file():raise ValueError('FFmpeg não encontrado no ZIP original.')
    print('Preparação concluída. Execute CONFIGURAR.bat e depois INICIAR.bat.',flush=True)
    return count

def main():
    if len(sys.argv)>1:source=sys.argv[1]
    else:
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw()
        source=filedialog.askopenfilename(title='Selecione o ZIP original 06.4-estudio',filetypes=[('Arquivo ZIP','*.zip')]);window.destroy()
        if not source:print('Preparação cancelada; nenhum arquivo alterado.');return
    prepare(source)

if __name__=='__main__':
    try:main()
    except Exception as error:print('ERRO:',error);sys.exit(1)
