// 06.0 extends the 05.9 timeline and playback tools.
let native06=[],edges06=[],fx06=[],events06=[],markers06=[],fxManual06=false,fxKey06='',lastPlan06={};
let exported06=null;
const isImage06=path=>/\.(png|jpe?g|webp|bmp)$/i.test(path);
const el06=(tag,text,parent)=>{const e=document.createElement(tag);if(text)e.textContent=text;if(parent)parent.append(e);return e};
const button06=(text,fn,parent)=>{const e=el06('button',text,parent);e.className='secondary';e.onclick=fn;return e};
const styles06=el06('style',null,document.head);styles06.textContent=`.junction06{position:absolute;top:0;z-index:400;transform:translateX(-50%);padding:1px 4px;border-radius:3px;background:#80612b;height:18px;font-size:12px}.junction06.off{background:#34445e}.lane06{position:relative;height:40px;background:#101a2b;border:1px solid #40516a;border-radius:8px}.lane06 button{position:absolute;top:4px;height:30px;overflow:hidden;font-size:10px;padding:4px}.caption06{position:absolute;bottom:64px;left:6px;right:6px;text-align:center;color:white;font-weight:800;font-size:18px;line-height:1.1;text-shadow:0 2px 4px black;pointer-events:none;z-index:30}.caption06.pulse{animation:pulse06 .18s ease-out}@keyframes pulse06{0%{transform:scale(.94)}50%{transform:scale(1.04)}100%{transform:scale(1)}}dialog{background:#172033;color:#e8edf5;border:1px solid #64748b;border-radius:12px;max-width:650px;width:90%;padding:22px}dialog::backdrop{background:#0009}.stage06{position:relative;width:180px;height:320px;overflow:hidden;background:black}.stage06 video,.stage06 img{position:absolute;left:0;top:0;width:180px!important;height:320px;max-height:none!important;aspect-ratio:auto!important}.gradient06{position:absolute;top:211px;height:26px;width:180px;z-index:10;background:linear-gradient(transparent,#0006,transparent);pointer-events:none}.notice06{border-left:3px solid #d8a543;padding:10px;color:#e4c78d;font-size:12px}`;
const librarySection06=$('folder').closest('section');
const purpose06=el06('select',null);purpose06.id='purpose06';for(const [value,name] of [['','Pasta com subpastas'],['especialista','Vídeos do especialista'],['insercoes','Inserções / B-roll']]){const o=el06('option',name,purpose06);o.value=value}
$('folder').parentElement.insertBefore(purpose06,$('scan'));
$('folder').placeholder='Pasta de materiais, bases ou inserções';
const previewBox06=$('basePlayer').parentElement,stage06=el06('div',null,previewBox06);stage06.className='stage06';
for(const id of ['basePlayer','overlayPlayer','fadePlayer'])stage06.append($(id));
const image06=el06('img',null,stage06);image06.style.display='none';image06.alt='Inserção';
const gradient06=el06('div',null,stage06);gradient06.className='gradient06';gradient06.style.display='none';
const caption06=el06('div',null,stage06);caption06.className='caption06';
const captionTools06=el06('div',null,$('advancedSlot'));captionTools06.className='row';
button06('Gerar legendas do especialista',transcribe06,captionTools06);
button06('Revisar legendas',()=>textDialog06(),captionTools06);
button06('Triagem facial experimental',faces06,captionTools06);
const transcriptionNote06=el06('span','Transcrição local opcional; requer INSTALAR_LEGENDAS.bat. SRT importado deve ser do especialista.',captionTools06);transcriptionNote06.className='sub';
const captionLabel06=el06('div','LEGENDAS',$('musicTimeline').parentElement);captionLabel06.className='sub';
const captionLane06=el06('div',null,$('musicTimeline').parentElement);captionLane06.className='lane06';
const sfxLabel06=el06('div','EFEITOS SONOROS — clique para ajustar',$('musicTimeline').parentElement);sfxLabel06.className='sub';
const sfxLane06=el06('div',null,$('musicTimeline').parentElement);sfxLane06.className='lane06';
const layoutLabel06=el06('label','Layout ', $('editControls'));
const layout06=el06('select',null,layoutLabel06);for(const [v,t] of [['full','Tela cheia'],['split','Split 70/30']]){const o=el06('option',t,layout06);o.value=v}
button06('Detectar bordas pretas',detectSelected06,$('editControls'));
const cropLabel06=el06('label','Recorte vertical (0–1) ', $('editControls'));
const cropTop06=el06('input',null,cropLabel06),cropBottom06=el06('input',null,cropLabel06);for(const e of [cropTop06,cropBottom06]){e.type='number';e.min='0';e.max='1';e.step='.01'}
const replace06=el06('select',null,$('editControls'));replace06.title='Substituir inserção';
button06('Substituir',()=>{const v=videos.find(v=>v.path===replace06.value),c=clips[selected];if(v&&c){Object.assign(c,{path:v.path,name:v.name,source_start:0,duration:Math.min(c.duration,v.duration),layout:'full'});delete c.crop;draw()}},$('editControls'));
const notice06=el06('div','Transições nativas: estrutura extraída de projetos reais. Abertura e aparência no CapCut 9.5.0 ainda precisam de validação. O preview é aproximado.',$('export').closest('section'));notice06.className='notice06';
const registerRow06=el06('div',null,$('advancedSlot'));registerRow06.className='row';
const registerIndex06=el06('input',null,registerRow06);registerIndex06.placeholder='Caminho do root_meta_info.json do CapCut';registerIndex06.style.minWidth='330px';
button06('Registrar última exportação no CapCut',async()=>{try{if(!exported06)throw Error('Exporte um projeto primeiro.');const result=await api('/api/capcut/register',{project:exported06,index:registerIndex06.value});msg('Projeto registrado. Abra o CapCut. Backup: '+(result.backup||'já registrado'))}catch(e){msg(e.message,true)}},registerRow06);
function extent06(){return Math.max(Number($('zoom').value),totalTime(),...clips.map(c=>c.start+c.duration),10)}
function reconcile06(){
 const sorted=[...clips].sort((a,b)=>a.start-b.start);const previous=new Map(edges06.map(e=>[e.key,e]));const fresh=[];
 for(let i=0;i<sorted.length;i++){
  const c=sorted[i];c.id=c.id||crypto.randomUUID();
  const prev=sorted[i-1],next=sorted[i+1];
  const contiguous=prev&&Math.abs(prev.start+prev.duration-c.start)<.002;
  const boundaries=[{key:contiguous?prev.id+':'+c.id:c.id+':in',time:c.start,automatic:!contiguous||prev.layout!==c.layout}];
  if(!next||Math.abs(c.start+c.duration-next.start)>=.002)boundaries.push({key:c.id+':out',time:c.start+c.duration,automatic:true});
  for(const e of boundaries){if(e.time<=0||e.time>=totalTime()-.01)continue;const old=previous.get(e.key);fresh.push({...e,resource_id:old?old.resource_id:(e.automatic?native06.find(n=>n.name==='Brilho 2')?.resource_id||native06[0]?.resource_id||null:null),duration:old?.duration||.35})}
 }
 edges06=fresh;
}
function autoFx06(){
 if(fxManual06)return;
 const choices=fx06.flatMap(m=>(m.regions?.length?m.regions:(m.duration<=12?[{source_start:0,duration:m.duration,peak_s:m.peak_s||0}]:[])).map(r=>({...r,path:m.path,name:m.name})));
 events06=[];if(!choices.length)return;let end=0;
 for(const [i,e] of edges06.filter(x=>x.resource_id).sort((a,b)=>a.time-b.time).entries()){
  const f=choices[i%choices.length];let start=e.time-f.peak_s,src=f.source_start,duration=f.duration;if(start<0){src-=start;duration+=start;start=0}duration=Math.min(duration,totalTime()-start);if(start<end||duration<.1)continue;
  events06.push({...f,start,source_start:src,duration,edge:e.time,gain:Number($('sfxVolume').value)});end=start+duration;
 }
}
function dialog06(title){const d=el06('dialog',null,document.body);el06('h2',title,d);d.addEventListener('close',()=>d.remove());return d}
function transitionDialog06(edge){
 const d=dialog06('Transição em '+edge.time.toFixed(2)+'s');const select=el06('select',null,d);select.style.width='100%';const none=el06('option','Corte seco',select);none.value='';
 for(const n of native06){const o=el06('option',n.name+' · '+n.resource_id,select);o.value=n.resource_id}select.value=edge.resource_id||'';
 const row=el06('div',null,d);row.className='row';el06('label','Duração em segundos',row);const duration=el06('input',null,row);duration.type='number';duration.step='.05';duration.min='.05';duration.max='1.5';duration.value=edge.duration;
 el06('p','Preview aproximado. Recurso nativo editável exportado com referência no segmento anterior ao corte.',d).className='sub';
 button06('Aplicar',()=>{edge.resource_id=select.value||null;edge.duration=Math.max(.05,Math.min(1.5,Number(duration.value)||.35));fxManual06=false;draw();renderAt(position);d.close()},d);
 button06('Cancelar',()=>d.close(),d);d.showModal();
}
const drawOld06=draw;draw=function(){
 reconcile06();drawOld06();autoFx06();const extent=extent06();
 for(const edge of edges06){const b=button06('◆',()=>transitionDialog06(edge),$('timeline'));b.className='junction06'+(edge.resource_id?'':' off');b.style.left=edge.time/extent*100+'%';b.title=(native06.find(n=>n.resource_id===edge.resource_id)?.name||'Corte seco')+' · '+edge.time.toFixed(2)+'s'}
 captionLane06.replaceChildren();for(const [i,c] of captions.entries()){const b=button06(c.text,()=>textDialog06(i),captionLane06);b.style.left=c.start/extent*100+'%';b.style.width=Math.max(.5,(c.end-c.start)/extent*100)+'%';b.style.background='#29575a'}
 sfxLane06.replaceChildren();for(const [i,e] of events06.entries()){const b=button06(e.name,()=>sfxDialog06(i),sfxLane06);b.style.left=e.start/extent*100+'%';b.style.width=Math.max(.5,e.duration/extent*100)+'%';b.style.background='#895c39'}
 for(const marker of markers06){const m=el06('span','⚑',$('baseTimeline'));m.title=marker.reason+' — triagem preliminar';m.style.cssText=`position:absolute;left:${marker.start/extent*100}%;top:0;color:#ffba6b;z-index:300`}
 const c=clips[selected];if(c){layout06.value=c.layout||'full';cropTop06.value=c.crop?.top??0;cropBottom06.value=c.crop?.bottom??1;replace06.replaceChildren();for(const v of brollPool()){const o=el06('option',v.name,replace06);o.value=v.path}replace06.value=c.path}
};
layout06.onchange=()=>{const c=clips[selected];if(c){c.layout=layout06.value;draw();renderAt(position)}};
for(const e of [cropTop06,cropBottom06])e.onchange=()=>{const c=clips[selected],top=Number(cropTop06.value),bottom=Number(cropBottom06.value);if(c&&top>=0&&bottom<=1&&bottom>top){c.crop={top,bottom};renderAt(position)}else msg('Recorte inválido.',true)};
async function detectSelected06(){const c=clips[selected];if(!c)return;try{const r=await api('/api/split/detect',{path:c.path});if(r.detected){c.layout='split';c.crop=r.crop;draw();renderAt(position)}msg(r.reason)}catch(e){msg(e.message,true)}}
const renderOld06=renderAt;renderAt=function(t){
 renderOld06(t);const c=clipAt(position),split=c?.layout==='split';const base=$('basePlayer'),overlay=$('overlayPlayer');
 base.style.height=split?'224px':'320px';base.style.objectFit=split?'cover':'contain';base.style.objectPosition='50% 35%';
 gradient06.style.display=split?'block':'none';image06.style.display='none';
 let visual=overlay;if(c&&isImage06(c.path)){overlay.style.display='none';overlay.pause();image06.style.display='block';if(image06.dataset.path!==c.path){image06.dataset.path=c.path;image06.src=source(c.path)}visual=image06}
 for(const e of [overlay,image06]){e.style.objectFit=split?'fill':'contain';e.style.clipPath='none';e.style.transform='none';e.style.height='320px';e.style.top='0'}
 if(split){const top=c.crop?.top??0,bottom=c.crop?.bottom??1,h=96/Math.max(.01,bottom-top);visual.style.height=h+'px';visual.style.top=(224-top*h)+'px';visual.style.clipPath=`inset(${top*100}% 0 ${(1-bottom)*100}% 0)`}
 if(c){
  const entry=edges06.find(e=>Math.abs(e.time-c.start)<.002&&e.resource_id),exit=edges06.find(e=>Math.abs(e.time-(c.start+c.duration))<.002&&e.resource_id);
  const alpha=Math.min(entry?Math.min(1,(position-c.start)/entry.duration):1,exit?Math.min(1,(c.start+c.duration-position)/exit.duration):1);
  visual.style.opacity=String(Math.max(0,alpha));
 }else overlay.style.opacity='1';
 const cap=captions.find(c=>position>=c.start&&position<c.end);if(caption06.textContent!==(cap?.text||'')){caption06.textContent=cap?.text||'';caption06.classList.remove('pulse');void caption06.offsetWidth;caption06.classList.add('pulse')}
 syncFx06(position);
};
function syncFx06(t){const el=$('sfxPlayer');const e=$('sfxMode').value==='on'?events06.find(e=>t>=e.start&&t<e.start+e.duration):null;if(!playing||!e){el.pause();if(!e)fxKey06='';return}const key=e.path+'|'+e.start;if(fxKey06!==key){fxKey06=key;el.src=source(e.path);el.load()}const offset=t-e.start,sourceTime=e.source_start+offset;if(el.readyState>=1&&Math.abs(el.currentTime-sourceTime)>.15)el.currentTime=sourceTime;el.volume=Math.max(0,Math.min(1,e.gain*Math.min(1,offset/.08,(e.duration-offset)/.15)));if(el.paused&&el.readyState>=2)el.play().catch(()=>{})}
const stopOld06=stopPlayback;stopPlayback=function(){stopOld06();$('sfxPlayer').pause();fxKey06=''};
const planOld06=plan;plan=function(){reconcile06();autoFx06();return {...planOld06(),version:'06.0',captions,transitions:edges06,sfxEvents:events06,sfxManual:true,sfxMode:$('sfxMode').value,sfxVolume:Number($('sfxVolume').value),markers:markers06}};
const reloadOld06=reload;reload=async function(){lastPlan06=await api('/api/plan');edges06=lastPlan06.transitions||[];events06=lastPlan06.sfxEvents||[];fxManual06=!!lastPlan06.sfxManual;markers06=lastPlan06.markers||[];$('sfxMode').value=lastPlan06.sfxMode||'on';$('sfxVolume').value=lastPlan06.sfxVolume??.3;fx06=await api('/api/sfx');await reloadOld06();captions=lastPlan06.captions||[];draw();renderAt(position)};
$('scan').onclick=async()=>{try{const d=await api('/api/scan',{folder:$('folder').value,category:purpose06.value||null});videos=await api('/api/videos');categories();renderLibrary();organizeBases(false);msg(d.count+' materiais lidos. Músicas e efeitos não entram no B-roll.')}catch(e){msg(e.message,true)}};
$('scanSfx').onclick=async()=>{try{msg('Analisando efeitos e regiões de som...');const r=await api('/api/sfx/scan',{folder:$('sfxFolder').value});fx06=r.items;fxManual06=false;draw();$('sfxInfo').textContent=fx06.length+' arquivos; '+fx06.reduce((n,x)=>n+(x.regions?.length||0),0)+' regiões detectadas'}catch(e){msg(e.message,true)}};
for(const e of [$('sfxMode'),$('sfxVolume')])e.onchange=()=>{if(!fxManual06)autoFx06();renderAt(position)};
$('createAll').onclick=async()=>{
 try{
  organizeBases(false);const pool=brollPool();if(!bases.length||!pool.length)throw Error('Carregue especialista e inserções.');
  const length=bases.reduce((n,b)=>n+b.duration,0);const r=await api('/api/suggest',{profile:$('profilePath').value,length});clips=r.clips;selected=-1;edges06=[];events06=[];fxManual06=false;
  msg('Montagem por blocos criada. Analisando bordas pretas das inserções...');const detected=new Map();
  for(const c of clips){if(!isImage06(c.path)){if(!detected.has(c.path))detected.set(c.path,await api('/api/split/detect',{path:c.path}));const result=detected.get(c.path);if(result.detected){c.layout='split';c.crop=result.crop}}}
  draw();renderAt(0);msg('Montagem pronta. Revise cortes, split-screen e legendas.');
 }catch(e){msg(e.message,true)}
};
$('generate').onclick=()=> $('createAll').click();
$('export').onclick=async()=>{try{stopPlayback();msg('Exportando projeto novo; preparando faixas de áudio...');const r=await api('/api/export',{...plan(),project:$('project').value});exported06=r.project;msg(r.inserted+' inserções exportadas para '+r.project+'. Registre no CapCut em Avançado.')}catch(e){msg(e.message,true)}};
$('srtFile').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const segments=[];for(const block of (await f.text()).replace(/\r/g,'').split(/\n\s*\n/)){const m=block.match(/(\d\d):(\d\d):(\d\d)[,.](\d{3})\s*-->\s*(\d\d):(\d\d):(\d\d)[,.](\d{3})/);if(m){const sec=a=>+a[0]*3600+ +a[1]*60+ +a[2]+ +a[3]/1000;segments.push({start:sec(m.slice(1,5)),end:sec(m.slice(5,9)),text:block.slice(m.index+m[0].length).trim().replace(/<[^>]*>/g,' ')})}}const r=await api('/api/captions/import',{segments});captions=r.captions;draw();msg(captions.length+' legendas. Tempos por palavra interpolados a partir do SRT; revise sincronização.')}catch(e){msg(e.message,true)}};
async function transcribe06(){try{msg('Preparando transcrição do especialista...');const r=await api('/api/captions/transcribe',plan());const poll=async()=>{try{const job=await api('/api/jobs?id='+r.job);if(job.status==='done'){captions=job.captions;draw();msg('Legendas geradas exclusivamente das bases.')}else if(job.status==='error')msg(job.error,true);else{msg(job.progress);setTimeout(poll,2000)}}catch(e){msg(e.message,true)}};poll()}catch(e){msg(e.message,true)}}
async function faces06(){try{markers06=[];for(const b of bases){const r=await api('/api/faces/preliminary',{base:b});markers06.push(...r.markers);msg(r.warning)}draw()}catch(e){msg(e.message,true)}}
function textDialog06(index=0){if(!captions.length)return msg('Gere legendas ou importe um SRT do especialista.',true);const c=captions[Math.max(0,index)];const d=dialog06('Revisar legenda');const text=el06('input',null,d);text.value=c.text;text.style.width='100%';const start=el06('input',null,d),end=el06('input',null,d);for(const e of [start,end]){e.type='number';e.step='.01'}start.value=c.start;end.value=c.end;button06('Salvar',()=>{if(+start.value>=0&&+end.value>+start.value){Object.assign(c,{text:text.value,start:+start.value,end:+end.value});draw();d.close()}},d);button06('Excluir',()=>{captions.splice(captions.indexOf(c),1);draw();d.close()},d);button06('Fechar',()=>d.close(),d);d.showModal()}
function sfxDialog06(i){const e=events06[i],d=dialog06('Ajustar '+e.name),fields={};for(const [key,label] of [['start','Início na timeline'],['source_start','Início no arquivo'],['duration','Duração'],['gain','Volume']]){const l=el06('label',label+' ',d),input=el06('input',null,l);input.type='number';input.step='.01';input.value=e[key];fields[key]=input;el06('br',null,d)}button06('Salvar',()=>{for(const [k,v] of Object.entries(fields))e[k]=Number(v.value);fxManual06=true;draw();d.close()},d);button06('Excluir',()=>{events06.splice(i,1);fxManual06=true;draw();d.close()},d);button06('Fechar',()=>d.close(),d);d.showModal()}
async function boot06(){try{native06=await api('/api/transitions/library');$('profilePath').value='reference/perfil_estilo_corrigido.json';await init();draw()}catch(e){msg(e.message,true)}}
// One playback clock across multiple bases; never reuse the old base's local time.
tick=function(ts){
 if(!playing)return;
 const base=baseAt(position),el=$('basePlayer');
 if(base&&el.dataset.path===base.path&&el.readyState>=2&&!el.paused)position=base.start+el.currentTime-(base.source_start||0);
 else if(base&&el.ended&&lastTick)position+=Math.min(.1,(ts-lastTick)/1000);
 lastTick=ts;
 if(position>=totalTime()-.025){stopPlayback();position=0;renderAt(0);return}
 renderAt(position);
 for(const id of ['basePlayer','overlayPlayer']){const video=$(id);if(video.style.display!=='none'&&video.readyState>=2&&video.paused&&!video.ended)video.play().catch(e=>{if(id==='basePlayer')msg(e.message,true)})}
 requestAnimationFrame(tick);
};
musicPosition=function(t){const duration=musicDuration(),overlap=Math.min(musicCrossfade,duration*.4);if(!duration)return null;const cycle=Math.max(.1,duration-overlap),index=Math.floor(t/cycle);return {index,local:t-index*cycle,overlap,cycle}};
const bootPromise064=boot06();
