import copy, json, subprocess, sys, shutil, unittest, wave, uuid
from unittest.mock import patch
from pathlib import Path
APP=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP/'backend'))
from catalog import scan, category_for, probe
from editor06 import split_detection, audio_analysis, validate, caption_groups, library, sfx_events
from export06 import export_plan, assert_draft
from main import scan_music
from register_capcut import register
from integrations import imported_transcript, suggest_by_transcript, review, signature, upstream, create_graphic, asset_path

def ff(*args):
    subprocess.run(['ffmpeg','-v','error','-y',*map(str,args)],check=True,capture_output=True,timeout=90)

class Regression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root=APP/'tests'/('vsl06_test_'+uuid.uuid4().hex);cls.root.mkdir()
        for name in ('especialista','insercoes','musicas','transicoes','export'): (cls.root/name).mkdir()
        cls.base=cls.root/'especialista/base1.mp4';cls.roll=cls.root/'insercoes/strip.mp4';cls.music=cls.root/'musicas/base2.mp4';cls.sfx=cls.root/'transicoes/swoosh.wav'
        ff('-f','lavfi','-i','color=c=blue:s=180x320:r=24:d=20','-f','lavfi','-i','sine=frequency=440:sample_rate=48000:duration=20','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',cls.base)
        ff('-f','lavfi','-i','color=c=yellow:s=180x96:r=24:d=6','-vf','pad=180:320:0:112:black','-c:v','libx264','-pix_fmt','yuv420p',cls.roll)
        ff('-f','lavfi','-i','color=c=black:s=90x160:r=24:d=7','-f','lavfi','-i','sine=frequency=330:sample_rate=48000:duration=7','-af',r'volume=0:enable=lt(t\,1)','-c:v','libx264','-c:a','aac','-shortest',cls.music)
        ff('-f','lavfi','-i','sine=frequency=880:sample_rate=48000:duration=15','-af',"volume='if(between(t,1,2)+between(t,5,6)+between(t,11,12),1,0)':eval=frame",cls.sfx)
        cls.catalog=scan(cls.root)
        cls.music_catalog=scan_music(cls.root/'musicas');cls.fx_catalog=scan_music(cls.root/'transicoes')
        rid=next(m['resource_id'] for m in library() if m['name']=='Brilho 2')
        cls.plan={'bases':[{'path':str(cls.base),'name':cls.base.name,'start':0.,'duration':probe(cls.base)['duration'],'source_start':0}], 'clips':[{'path':str(cls.roll),'name':'Broll','start':3.,'duration':3.,'source_start':0},{'path':str(cls.roll),'name':'Split','start':6.,'duration':3.,'source_start':0.,'layout':'split','crop':{'top':.35,'bottom':.65}}], 'captions':[{'start':1.,'end':2.,'text':'voz do especialista'}], 'transitions':[{'time':t,'resource_id':rid,'duration':.35} for t in (3.,6.,9.)], 'voice':1.,'music':.3,'insertVolume':.3,'sfxVolume':.3,'musicPath':str(cls.music),'project':str(cls.root/'export')}
    @classmethod
    def tearDownClass(cls):
        if cls.root.resolve().parent!=(APP/'tests').resolve():raise RuntimeError('Invalid test cleanup path')
        shutil.rmtree(cls.root)
    def test_folder_purpose_overrides_mp4_and_base_name(self):
        idx={v['path']:v for v in self.catalog}
        self.assertEqual(idx[str(self.music)]['category'],'musicas')
        self.assertEqual(category_for(self.music,self.root,'insercoes'),'musicas')
        self.assertEqual(idx[str(self.roll)]['category'],'insercoes')
    def test_black_border_detection(self):
        r=split_detection(self.roll);self.assertTrue(r['detected']);self.assertAlmostEqual(r['crop']['top'],.35,delta=.03)
        self.assertFalse(split_detection(self.base)['detected'])
    def test_long_sfx_segmentation_and_music_silence(self):
        self.assertGreaterEqual(len(self.fx_catalog[0]['regions']),3)
        self.assertGreater(self.music_catalog[0]['audible_start_s'],.8)
        events=sfx_events(self.plan,self.fx_catalog)
        self.assertTrue(events)
        for e in events:self.assertAlmostEqual(e['start']+e['peak_s'],e['edge'],places=3)
    def test_audio_mp4_cannot_be_broll(self):
        bad=copy.deepcopy(self.plan);bad['clips'][0]['path']=str(self.music)
        with self.assertRaisesRegex(ValueError,'categoria insercoes'):validate(bad,self.catalog)
    def test_narration_cannot_be_trimmed(self):
        bad=copy.deepcopy(self.plan);bad['bases'][0]['duration']-=1
        with self.assertRaisesRegex(ValueError,'narração'):validate(bad,self.catalog)
    def test_three_word_captions_and_word_timing(self):
        c=caption_groups([{'start':0,'end':2,'words':[{'word':str(i),'start':i*.2,'end':(i+1)*.2} for i in range(8)]}])
        self.assertEqual([len(x['text'].split()) for x in c],[3,3,2]);self.assertEqual(c[1]['start'],.6)
    def test_registration_preserves_existing_projects_and_backup(self):
        folder=self.root/'registration';folder.mkdir();index=self.root/'root_meta_info.json'
        original={'all_draft_store':[{'draft_id':'existing','draft_name':'keep'}],'draft_ids':1,'root_path':'preserved'}
        index.write_text(json.dumps(original),encoding='utf-8')
        (folder/'draft_content.json').write_text('{}',encoding='utf-8')
        (folder/'draft_meta_info.json').write_text(json.dumps({'draft_id':'generated','draft_name':'VSL06'}),encoding='utf-8')
        with patch('subprocess.run',return_value=type('Result',(),{'stdout':'','returncode':0})()):
            result=register(folder,index);again=register(folder,index)
        current=json.loads(index.read_text(encoding='utf-8'))
        self.assertEqual(current['all_draft_store'][1],original['all_draft_store'][0])
        self.assertEqual(current['root_path'],'preserved');self.assertEqual(current['draft_ids'],2)
        self.assertEqual(json.loads(Path(result['backup']).read_text(encoding='utf-8')),original)
        self.assertTrue(again['already_registered'])
    def test_registration_refuses_unverifiable_process_state(self):
        import os
        if os.name!='nt':self.skipTest('Windows process check')
        folder=self.root/'registration_denied';folder.mkdir();index=self.root/'denied'/'root_meta_info.json';index.parent.mkdir()
        original={'all_draft_store':[],'draft_ids':0};index.write_text(json.dumps(original),encoding='utf-8')
        (folder/'draft_content.json').write_text('{}',encoding='utf-8')
        (folder/'draft_meta_info.json').write_text(json.dumps({'draft_id':'generated'}),encoding='utf-8')
        with patch('subprocess.run',return_value=type('Result',(),{'stdout':'','returncode':1})()):
            with self.assertRaises(ValueError):register(folder,index)
        self.assertEqual(json.loads(index.read_text(encoding='utf-8')),original)
    def test_export_native_refs_audio_and_editable_layers(self):
        result=export_plan(self.plan,self.catalog,self.music_catalog,self.fx_catalog)
        project=Path(result['project']);data=json.loads((project/'draft_content.json').read_text(encoding='utf-8'))
        assert_draft(data)
        broll=[t for t in data['tracks'] if t['name']=='VSL06 B-ROLL'];self.assertEqual(len(broll),1)
        voice=next(t for t in data['tracks'] if t['name']=='VSL06 VOZ INTEGRAL');self.assertEqual(voice['segments'][0]['target_timerange']['duration'],20000000)
        self.assertEqual(len(data['materials']['transitions']),3)
        ids={m['id'] for m in data['materials']['transitions']};refs=[r for s in broll[0]['segments'] for r in s['extra_material_refs']];self.assertEqual(ids,set(refs))
        self.assertEqual(len(data['materials']['texts']),1)
        texts=next(t for t in data['tracks'] if t['type']=='text');self.assertTrue(texts['segments'][0]['common_keyframes'])
        music_tracks=[t for t in data['tracks'] if 'MÚSICA' in t['name']];self.assertEqual(len(music_tracks),2)
        self.assertEqual(music_tracks[0]['segments'][0]['target_timerange']['start'],0)
        self.assertGreater(len(music_tracks[0]['segments']),1)
        fades=data['materials']['audio_fades'];self.assertTrue(any(m['fade_in_duration']>0 for m in fades))
        self.assertTrue(any(t['name']=='VSL06 DIVISÃO SPLIT' for t in data['tracks']))
        self.assertEqual(result['validation']['capcut_9_5_open_test'],'pending')
        audio_id=voice['segments'][0]['material_id'];audio=next(m for m in data['materials']['audios'] if m['id']==audio_id)
        with wave.open(audio['path'],'rb') as wav:self.assertGreaterEqual(wav.getnframes()/wav.getframerate(),20.)
        self.assertTrue(self.base.exists())
    def test_video_use_import_has_offset_and_rejects_audio_broll(self):
        base=dict(self.plan['bases'][0],start=12)
        raw={'words':[{'text':str(i),'type':'word','start':i*.2,'end':(i+1)*.2} for i in range(4)]}
        result=imported_transcript({'base':base,'transcript':raw},self.catalog)
        self.assertEqual(result['captions'][0]['start'],12)
        self.assertEqual(result['captions'][1]['start'],12.6)
        with self.assertRaises(ValueError):imported_transcript({'base':dict(base,path=str(self.music)),'transcript':raw},self.catalog)
    def test_video_use_packing_and_cached_review(self):
        first=review(self.plan,self.catalog,panels=False);second=review(self.plan,self.catalog,panels=False)
        self.assertTrue(second['cached']);self.assertTrue(first['voice_preserved'])
        self.assertIn('voz do especialista',second['packed_text'])
        changed=copy.deepcopy(self.plan);changed['captions'][0]['text']='mudou'
        self.assertNotEqual(signature(self.plan),signature(changed))
        with self.assertRaises(ValueError):asset_path('../../backend/main.py')
    def test_speech_suggestions_preserve_voice_and_start_times(self):
        before=copy.deepcopy(self.plan);before['captions']=[{'start':3,'end':6,'text':'strip produto'}]
        result=suggest_by_transcript(before,self.catalog)
        self.assertEqual([c['start'] for c in result['clips']],[c['start'] for c in before['clips']])
        self.assertEqual(before['bases'],self.plan['bases'])
        self.assertTrue(all(c['path']==str(self.roll) for c in result['clips']))
    def test_real_video_use_timeline_panel(self):
        timeline=upstream('timeline_view');out=self.root/'video_use_panel.png'
        timeline.render_timeline(self.base,0,1,out,n_frames=3,transcript=None)
        self.assertEqual(out.read_bytes()[:8],b'\x89PNG\r\n\x1a\n')
    def test_hyperframes_template_escapes_title(self):
        import os
        if not os.environ.get('VSL_HYPERFRAMES_CLI'):self.skipTest('Optional HyperFrames runtime not installed')
        folder=create_graphic({'title':'<script>alert(1)</script>','subtitle':'Teste','duration':2})
        text=(folder/'index.html').read_text(encoding='utf-8')
        self.assertIn('&lt;script&gt;',text);self.assertIn('data-duration="2.0"',text)
        self.assertNotIn('<script>alert(1)</script>',text)
        self.assertTrue((folder/'gsap.min.js').exists())
        with self.assertRaises(ValueError):create_graphic({'title':'Teste','duration':100})
    def test_transcription_cache_skips_repeated_model_inference(self):
        import time,types
        from editor06 import transcribe_job,JOBS
        calls=[]
        word=types.SimpleNamespace(word='voz',start=1.,end=1.4)
        segment=types.SimpleNamespace(start=1.,end=1.4,text='voz',words=[word])
        class Model:
            def __init__(self,*args,**kwargs):calls.append('load')
            def transcribe(self,*args,**kwargs):calls.append('infer');return iter([segment]),None
        with patch.dict(sys.modules,{'faster_whisper':types.SimpleNamespace(WhisperModel=Model)}):
            for _ in range(2):
                id=transcribe_job(self.plan,self.catalog)['job']
                for _ in range(500):
                    if JOBS[id]['status']!='running':break
                    time.sleep(.01)
                self.assertEqual(JOBS[id]['status'],'done',JOBS[id])
                self.assertEqual(JOBS[id]['captions'][0]['words'][0]['start'],1.)
        self.assertEqual(calls,['load','infer'])

if __name__=='__main__':unittest.main(verbosity=2)
